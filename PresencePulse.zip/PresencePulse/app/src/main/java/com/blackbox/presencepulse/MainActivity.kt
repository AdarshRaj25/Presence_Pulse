package com.blackbox.presencepulse

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.rememberNavController
import com.blackbox.presencepulse.ble.BleBackgroundService
import com.blackbox.presencepulse.navigation.PresencePulseNavGraph
import com.blackbox.presencepulse.permissions.PermissionUtils
import com.blackbox.presencepulse.service.PhubDetectorService
import com.blackbox.presencepulse.ui.screens.AuthViewModel
import com.blackbox.presencepulse.ui.theme.BgPrimary
import com.blackbox.presencepulse.ui.theme.PresencePulseTheme
import com.google.firebase.auth.FirebaseAuth

class MainActivity : ComponentActivity() {

    private val authViewModel: AuthViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PresencePulseTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = BgPrimary) {
                    Box(modifier = Modifier.padding(top = 5.dp)) {
                        val navController = rememberNavController()
                        PresencePulseNavGraph(navController = navController)
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        authViewModel.updateHeartbeat()

        val isLoggedIn     = FirebaseAuth.getInstance().currentUser != null
        val hasPermissions = PermissionUtils.isBleGranted(this)

        if (isLoggedIn && hasPermissions) {
            BleBackgroundService.start(this)
            PhubDetectorService.start(this)   // ← start phub detector
        }
    }
}