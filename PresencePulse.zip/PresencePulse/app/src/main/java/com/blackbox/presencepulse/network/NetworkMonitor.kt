package com.blackbox.presencepulse.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.produceState
import androidx.compose.ui.platform.LocalContext

/**
 * Observes real-time network connectivity using ConnectivityManager callbacks.
 * Returns a Compose [State<Boolean>] — true = online, false = offline.
 *
 * Uses VALIDATED capability so a captive portal (hotel Wi-Fi that hasn't
 * been signed into) is correctly treated as offline.
 */
@Composable
fun rememberIsOnline(): State<Boolean> {
    val context = LocalContext.current

    return produceState(initialValue = context.isCurrentlyOnline()) {
        val connectivityManager =
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            .build()

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network)  { value = true  }
            override fun onLost(network: Network)       { value = false }
            override fun onUnavailable()                { value = false }
        }

        connectivityManager.registerNetworkCallback(request, callback)

        // Clean up when the composable leaves composition
        awaitDispose { connectivityManager.unregisterNetworkCallback(callback) }
    }
}

/** Synchronous one-shot check — used only for the initial [produceState] value. */
private fun Context.isCurrentlyOnline(): Boolean {
    val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val network = cm.activeNetwork ?: return false
    val caps    = cm.getNetworkCapabilities(network) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
           caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
}
