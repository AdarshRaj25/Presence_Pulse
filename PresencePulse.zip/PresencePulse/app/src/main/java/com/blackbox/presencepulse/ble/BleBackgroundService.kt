package com.blackbox.presencepulse.ble

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.bluetooth.BluetoothManager
import android.bluetooth.le.*
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.blackbox.presencepulse.R
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Foreground BLE service — runs continuously, screen on or off.
 *
 * Scan strategy: 10s ON / 5s OFF cycle via Handler.
 * This is far more responsive than SCAN_MODE_LOW_POWER (which can have
 * 30s+ gaps on some OEMs) while still being battery-friendly.
 *
 * TTL eviction: each seen entry stores a timestamp. Entries not refreshed
 * within 60 seconds are evicted — so "friends in range" reflects reality
 * and doesn't show people who left 10 minutes ago.
 */
class BleBackgroundService : Service() {

    inner class LocalBinder : Binder() {
        fun getService() = this@BleBackgroundService
    }
    private val binder = LocalBinder()
    override fun onBind(intent: Intent): IBinder = binder

    // ── Bluetooth ─────────────────────────────────────────────────────────────
    private val btAdapter get() =
        (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private val leScanner  get() = btAdapter?.bluetoothLeScanner
    private val leAdvert   get() = btAdapter?.bluetoothLeAdvertiser

    private var isScanning    = false
    private var isAdvertising = false

    // ── Periodic scan handler ─────────────────────────────────────────────────
    private val handler = Handler(Looper.getMainLooper())

    // lateinit var avoids circular-reference type inference error between two
    // vals that reference each other at initialisation time.
    private lateinit var startScanRunnable: Runnable
    private lateinit var stopScanRunnable: Runnable

    private fun initRunnables() {
        startScanRunnable = Runnable {
            doStartScan()
            handler.postDelayed(stopScanRunnable, SCAN_DURATION_MS)
        }
        stopScanRunnable = Runnable {
            doStopScan()
            evictStaleEntries()
            handler.postDelayed(startScanRunnable, SCAN_GAP_MS)
        }
    }

    // ── TTL map: key → last seen timestamp ────────────────────────────────────
    // Key is either a UID prefix string or an "rssi_N" bucket string
    private val seenTimestamps = mutableMapOf<String, Long>()

    // ── Advertise callback ────────────────────────────────────────────────────
    private val advertiseCallback = object : AdvertiseCallback() {
        override fun onStartSuccess(s: AdvertiseSettings) { isAdvertising = true }
        override fun onStartFailure(e: Int)               { isAdvertising = false }
    }

    // ── Scan callback ─────────────────────────────────────────────────────────
    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) = recordResult(result)
        override fun onBatchScanResults(results: List<ScanResult>) = results.forEach { recordResult(it) }
        override fun onScanFailed(errorCode: Int) { isScanning = false; _isScanning.value = false }
    }

    private fun recordResult(result: ScanResult) {
        val mfData = result.scanRecord
            ?.getManufacturerSpecificData(BleConstants.MANUFACTURER_ID)

        val key = if (mfData != null && mfData.isNotEmpty()) {
            mfData.toString(Charsets.UTF_8)
        } else {
            "rssi_${(result.rssi / 5) * 5}"
        }

        val now = System.currentTimeMillis()
        seenTimestamps[key] = now

        // Rebuild the StateFlow sets from the live timestamp map
        val allKeys = seenTimestamps.keys.toSet()
        _nearbyUidPrefixes.value = allKeys
        _deviceCount.value       = allKeys.size

        // Start social timer when first device appears
        if (allKeys.isNotEmpty() && socialStartMs == 0L) {
            socialStartMs = System.currentTimeMillis()
        }
    }

    // Remove entries not seen within the TTL window
    private fun evictStaleEntries() {
        val cutoff = System.currentTimeMillis() - TTL_MS
        val stale  = seenTimestamps.entries.filter { it.value < cutoff }.map { it.key }
        if (stale.isNotEmpty()) {
            stale.forEach { seenTimestamps.remove(it) }
            val allKeys = seenTimestamps.keys.toSet()
            _nearbyUidPrefixes.value = allKeys
            _deviceCount.value       = allKeys.size

            // Accumulate social minutes when last device leaves range
            if (allKeys.isEmpty() && socialStartMs > 0L) {
                val elapsedMins = ((System.currentTimeMillis() - socialStartMs) / 60_000).toInt()
                _socialMinutesToday.value += elapsedMins
                socialStartMs = 0L
            }
        }

        // Also accumulate while devices are still present (running total)
        if (seenTimestamps.isNotEmpty() && socialStartMs > 0L) {
            val elapsedMins = ((System.currentTimeMillis() - socialStartMs) / 60_000).toInt()
            _socialMinutesToday.value = (_socialMinutesToday.value) + elapsedMins
            socialStartMs = System.currentTimeMillis() // reset start to avoid double-counting
        }
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAdvertising()
        // Initialise runnables then kick off the scan loop immediately
        initRunnables()
        handler.removeCallbacksAndMessages(null)
        handler.post(startScanRunnable)
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        doStopScan()
        stopAdvertising()
        super.onDestroy()
    }

    // ── Advertising ───────────────────────────────────────────────────────────

    private fun startAdvertising() {
        if (isAdvertising || !hasBleAdvertisePermission()) return
        val adv = leAdvert ?: return
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val uidBytes = uid.toByteArray(Charsets.UTF_8).take(8).toByteArray()

        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM)
            .setConnectable(false)
            .build()

        val data = AdvertiseData.Builder()
            .addServiceUuid(BleConstants.PRESENCE_PULSE_PARCEL_UUID)
            .addManufacturerData(BleConstants.MANUFACTURER_ID, uidBytes)
            .setIncludeDeviceName(false)
            .build()

        adv.startAdvertising(settings, data, advertiseCallback)
    }

    private fun stopAdvertising() {
        if (!isAdvertising) return
        try { leAdvert?.stopAdvertising(advertiseCallback) } catch (_: Exception) {}
        isAdvertising = false
    }

    // ── Scanning ──────────────────────────────────────────────────────────────

    private fun doStartScan() {
        if (isScanning || !hasBleScanPermission()) return
        val scanner = leScanner ?: return

        val filter = ScanFilter.Builder()
            .setServiceUuid(BleConstants.PRESENCE_PULSE_PARCEL_UUID)
            .build()

        // SCAN_MODE_BALANCED — good responsiveness without draining battery
        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_BALANCED)
            .build()

        scanner.startScan(listOf(filter), settings, scanCallback)
        isScanning        = true
        _isScanning.value = true
    }

    private fun doStopScan() {
        if (!isScanning) return
        try { leScanner?.stopScan(scanCallback) } catch (_: Exception) {}
        isScanning        = false
        _isScanning.value = false
    }

    // ── Permission checks ─────────────────────────────────────────────────────

    private fun hasBleAdvertisePermission() =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_ADVERTISE) == PackageManager.PERMISSION_GRANTED
        else true

    private fun hasBleScanPermission() =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
        else
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    // ── Notification ──────────────────────────────────────────────────────────

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "PresencePulse", NotificationManager.IMPORTANCE_MIN
            ).apply {
                setShowBadge(false)
                setSound(null, null)
                enableVibration(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("")
            .setContentText("")
            .setSilent(true)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET)
            .build()

    // ── Companion — process-wide StateFlows ───────────────────────────────────

    companion object {
        private const val CHANNEL_ID        = "pp_ble_channel"
        private const val NOTIFICATION_ID   = 1001
        private const val SCAN_DURATION_MS  = 10_000L  // scan for 10 seconds
        private const val SCAN_GAP_MS       = 5_000L   // pause for 5 seconds
        private const val TTL_MS            = 60_000L  // evict after 60 seconds

        private val _nearbyUidPrefixes = MutableStateFlow<Set<String>>(emptySet())
        val nearbyUidPrefixes: StateFlow<Set<String>> = _nearbyUidPrefixes.asStateFlow()

        private val _deviceCount = MutableStateFlow(0)
        val deviceCount: StateFlow<Int> = _deviceCount.asStateFlow()

        private val _isScanning = MutableStateFlow(false)
        val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

        // Tracks when a device was first seen in current session
        // Used to compute social minutes (total time with anyone nearby today)
        private var socialStartMs = 0L
        private val _socialMinutesToday = MutableStateFlow(0)
        val socialMinutesToday: StateFlow<Int> = _socialMinutesToday.asStateFlow()

        fun start(context: android.content.Context) {
            val intent = Intent(context, BleBackgroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                context.startForegroundService(intent)
            else
                context.startService(intent)
        }

        fun stop(context: android.content.Context) {
            context.stopService(Intent(context, BleBackgroundService::class.java))
        }
    }
}