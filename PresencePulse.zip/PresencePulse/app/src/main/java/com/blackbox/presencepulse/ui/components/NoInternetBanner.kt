package com.blackbox.presencepulse.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.blackbox.presencepulse.ui.theme.*

/**
 * Slides up from the bottom when offline, slides back down when restored.
 * navigationBarsPadding() is baked in so it always clears the system nav bar
 * on gesture-nav and 3-button-nav devices without any extra setup at the call site.
 *
 * Usage inside a Box:
 *   NoInternetBanner(
 *       isOnline = isOnline,
 *       modifier = Modifier.align(Alignment.BottomCenter)
 *   )
 */
@Composable
fun NoInternetBanner(isOnline: Boolean, modifier: Modifier = Modifier) {
    AnimatedVisibility(
        // navigationBarsPadding() is on the AnimatedVisibility wrapper so the
        // slide animation also respects the inset — the banner never starts
        // its travel from behind the nav bar.
        modifier = modifier.navigationBarsPadding(),
        visible = !isOnline,
        enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
        exit  = slideOutVertically(targetOffsetY = { it }) + fadeOut()
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Amber.copy(alpha = 0.12f))
                .border(1.dp, Amber.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("📡", fontSize = 16.sp)
                Column {
                    Text(
                        "No internet connection",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Amber
                    )
                    Text(
                        "Check your connection and try again.",
                        fontSize = 11.sp,
                        color = TextSecondary,
                        lineHeight = 16.sp
                    )
                }
            }
        }
    }
}