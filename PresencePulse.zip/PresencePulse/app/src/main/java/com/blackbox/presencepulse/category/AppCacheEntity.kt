package com.blackbox.presencepulse.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One row per unique package name ever seen.
 * Avoids hitting PackageManager on every poll cycle for already-known apps.
 *
 * category is the string returned by ApplicationInfo.category mapped to a
 * human label, e.g. CATEGORY_SOCIAL → "Social".
 * Falls back to "Other" for uncategorised or system apps.
 */
@Entity(tableName = "app_cache")
data class AppCacheEntity(
    @PrimaryKey
    val packageName : String,
    val appLabel    : String,
    val category    : String
)