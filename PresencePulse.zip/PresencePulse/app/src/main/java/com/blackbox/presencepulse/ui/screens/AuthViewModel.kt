package com.blackbox.presencepulse.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

data class AuthUiState(
    val isLoading        : Boolean = false,
    val errorMessage     : String? = null,
    val emailAlreadyExists: Boolean = false
)

data class ResetState(
    val message : String? = null,
    val isError : Boolean = false
)

class AuthViewModel : ViewModel() {

    private val auth = FirebaseAuth.getInstance()
    private val db   = FirebaseFirestore.getInstance()

    private val _signUpState = MutableStateFlow(AuthUiState())
    val signUpState: StateFlow<AuthUiState> = _signUpState.asStateFlow()

    private val _loginState = MutableStateFlow(AuthUiState())
    val loginState: StateFlow<AuthUiState> = _loginState.asStateFlow()

    private val _resetState = MutableStateFlow(ResetState())
    val resetState: StateFlow<ResetState> = _resetState.asStateFlow()

    // One-shot navigation events
    private val _signUpSuccess = MutableSharedFlow<Unit>(replay = 0)
    val signUpSuccess: SharedFlow<Unit> = _signUpSuccess.asSharedFlow()

    private val _loginSuccess = MutableSharedFlow<Unit>(replay = 0)
    val loginSuccess: SharedFlow<Unit> = _loginSuccess.asSharedFlow()

    // Drives HomeScreen name in real time
    private val _displayName = MutableStateFlow(auth.currentUser?.displayName.orEmpty())
    val displayName: StateFlow<String> = _displayName.asStateFlow()

    val isUserLoggedIn: Boolean get() = auth.currentUser != null
    val currentDisplayName: String get() = auth.currentUser?.displayName.orEmpty()

    // ── Sign Up ───────────────────────────────────────────────────────────────

    fun signUp(fullName: String, email: String, password: String) {
        if (!validateSignUp(fullName, email, password)) return
        viewModelScope.launch {
            _signUpState.update { it.copy(isLoading = true, errorMessage = null, emailAlreadyExists = false) }
            try {
                // 1. Create Auth account
                val result = auth.createUserWithEmailAndPassword(email.trim(), password).await()
                val uid    = result.user!!.uid

                // 2. Set display name on Auth profile
                result.user!!.updateProfile(
                    UserProfileChangeRequest.Builder()
                        .setDisplayName(fullName.trim())
                        .build()
                ).await()

                // 3. Write to Firestore.
                //    lastSeen is written immediately so this user is counted
                //    as active from day one. It will be refreshed every time
                //    the app opens via updateHeartbeat().
                db.collection("users").document(uid).set(
                    mapOf(
                        "uid"       to uid,
                        "name"      to fullName.trim(),
                        "nameLower" to fullName.trim().lowercase(),
                        "email"     to email.trim(),
                        "lastSeen"  to System.currentTimeMillis()
                    )
                ).await()

                _displayName.value = fullName.trim()
                _signUpState.update { it.copy(isLoading = false) }
                _signUpSuccess.emit(Unit)

            } catch (e: FirebaseAuthWeakPasswordException) {
                _signUpState.update { it.copy(isLoading = false, errorMessage = "Password must be at least 6 characters.") }
            } catch (e: FirebaseAuthUserCollisionException) {
                _signUpState.update { it.copy(isLoading = false, emailAlreadyExists = true) }
            } catch (e: FirebaseAuthInvalidCredentialsException) {
                _signUpState.update { it.copy(isLoading = false, errorMessage = "Please enter a valid email address.") }
            } catch (e: Exception) {
                _signUpState.update { it.copy(isLoading = false, errorMessage = e.message ?: "Sign up failed. Please try again.") }
            }
        }
    }

    // ── Log In ────────────────────────────────────────────────────────────────

    fun login(email: String, password: String) {
        if (!validateLogin(email, password)) return
        viewModelScope.launch {
            _loginState.update { it.copy(isLoading = true, errorMessage = null) }
            try {
                auth.signInWithEmailAndPassword(email.trim(), password).await()
                _displayName.value = auth.currentUser?.displayName.orEmpty()
                _loginState.update { it.copy(isLoading = false) }
                _loginSuccess.emit(Unit)
            } catch (e: FirebaseAuthInvalidCredentialsException) {
                _loginState.update { it.copy(isLoading = false, errorMessage = "Incorrect email or password.") }
            } catch (e: Exception) {
                _loginState.update { it.copy(isLoading = false, errorMessage = e.message ?: "Login failed. Please try again.") }
            }
        }
    }

    // ── Heartbeat — call from MainActivity.onResume() ─────────────────────────
    //
    // Writes the current timestamp to Firestore every time the app comes to
    // the foreground. DetectionViewModel filters out users whose lastSeen is
    // older than 7 days, treating them as having uninstalled the app.
    // Fire-and-forget: runs in viewModelScope, failures are silently ignored
    // so they never surface to the user.

    fun updateHeartbeat() {
        val uid = auth.currentUser?.uid ?: return
        viewModelScope.launch {
            try {
                db.collection("users").document(uid).set(
                    mapOf("lastSeen" to System.currentTimeMillis()),
                    SetOptions.merge()
                ).await()
            } catch (_: Exception) {
                // Silent — heartbeat failure is non-critical
            }
        }
    }

    // ── Update Display Name ───────────────────────────────────────────────────

    fun updateDisplayName(newName: String, onDone: (success: Boolean) -> Unit) {
        if (newName.isBlank()) { onDone(false); return }
        val uid = auth.currentUser?.uid ?: run { onDone(false); return }
        viewModelScope.launch {
            try {
                auth.currentUser!!.updateProfile(
                    UserProfileChangeRequest.Builder()
                        .setDisplayName(newName.trim())
                        .build()
                ).await()

                db.collection("users").document(uid).set(
                    mapOf(
                        "name"      to newName.trim(),
                        "nameLower" to newName.trim().lowercase()
                    ),
                    SetOptions.merge()
                ).await()

                _displayName.value = newName.trim()
                onDone(true)
            } catch (e: Exception) {
                onDone(false)
            }
        }
    }

    // ── Forgot Password ───────────────────────────────────────────────────────

    fun sendPasswordReset(email: String) {
        if (email.isBlank()) {
            _resetState.update { ResetState(message = "Enter your email above first.", isError = true) }
            return
        }
        viewModelScope.launch {
            _resetState.update { ResetState() }
            try {
                auth.sendPasswordResetEmail(email.trim()).await()
                _resetState.update { ResetState(message = "Reset link sent! Check your inbox.", isError = false) }
            } catch (e: FirebaseAuthInvalidUserException) {
                _resetState.update { ResetState(message = "No account found with this email.", isError = true) }
            } catch (e: FirebaseAuthInvalidCredentialsException) {
                _resetState.update { ResetState(message = "Please enter a valid email address.", isError = true) }
            } catch (e: Exception) {
                _resetState.update { ResetState(message = e.message ?: "Failed to send reset email.", isError = true) }
            }
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    fun clearResetState()  = _resetState.update { ResetState() }
    fun clearSignUpError() = _signUpState.update { it.copy(errorMessage = null, emailAlreadyExists = false) }
    fun clearLoginError()  = _loginState.update  { it.copy(errorMessage = null) }

    private fun validateSignUp(fullName: String, email: String, password: String): Boolean {
        return when {
            fullName.isBlank()  -> { _signUpState.update { it.copy(errorMessage = "Please enter your full name.") };            false }
            email.isBlank()     -> { _signUpState.update { it.copy(errorMessage = "Please enter your email.") };                false }
            password.isBlank()  -> { _signUpState.update { it.copy(errorMessage = "Please enter a password.") };                false }
            password.length < 6 -> { _signUpState.update { it.copy(errorMessage = "Password must be at least 6 characters.") }; false }
            else -> true
        }
    }

    private fun validateLogin(email: String, password: String): Boolean {
        return when {
            email.isBlank()    -> { _loginState.update { it.copy(errorMessage = "Please enter your email.") };    false }
            password.isBlank() -> { _loginState.update { it.copy(errorMessage = "Please enter your password.") }; false }
            else -> true
        }
    }
}