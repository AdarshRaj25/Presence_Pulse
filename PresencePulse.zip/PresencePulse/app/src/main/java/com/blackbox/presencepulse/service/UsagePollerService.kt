package com.blackbox.presencepulse.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.blackbox.presencepulse.data.db.AppDatabase
import com.blackbox.presencepulse.data.db.UsageEventEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class UsagePollerService : Service() {

    private val serviceScope   = CoroutineScope(Dispatchers.IO + Job())
    private val pollIntervalMs = 60_000L

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        serviceScope.launch { pollLoop() }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.coroutineContext[Job]?.cancel()
    }

    // ── Polling loop ──────────────────────────────────────────────────────────

    private suspend fun pollLoop() {
        val dao = AppDatabase.getInstance(applicationContext).usageEventDao()
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager

        while (true) {
            val endTime   = System.currentTimeMillis()
            val startTime = endTime - pollIntervalMs * 2   // 2-min overlap to avoid gaps

            // Android reuses the same Event object — store primitive fields immediately
            data class RawEvent(val pkg: String, val type: Int, val ts: Long)
            val rawEvents   = mutableListOf<RawEvent>()
            val usageEvents = usm.queryEvents(startTime, endTime)
            val event       = UsageEvents.Event()

            while (usageEvents.hasNextEvent()) {
                usageEvents.getNextEvent(event)
                if (event.eventType in intArrayOf(1, 2, 23, 24)) {
                    rawEvents.add(RawEvent(
                        pkg  = event.packageName ?: "",
                        type = event.eventType,
                        ts   = event.timeStamp
                    ))
                }
            }

            rawEvents.sortBy { it.ts }

            // Pair RESUME(1)+PAUSE(2) per package to compute durationMs
            val resumeMap = mutableMapOf<String, Long>()
            val toInsert  = mutableListOf<UsageEventEntity>()

            rawEvents.forEach { e ->
                val eventId = "${e.pkg}_${e.ts}_${e.type}"
                when (e.type) {
                    1 -> {
                        resumeMap[e.pkg] = e.ts
                        toInsert += UsageEventEntity(
                            id = 0, eventId = eventId,
                            packageName = e.pkg, appLabel = resolveLabel(e.pkg),
                            category = resolveCategory(e.pkg),
                            eventType = e.type, timeStamp = e.ts, durationMs = 0L
                        )
                    }
                    2 -> {
                        val resumeTime = resumeMap[e.pkg]
                        val duration   = if (resumeTime != null && e.ts > resumeTime)
                            e.ts - resumeTime else 0L
                        resumeMap.remove(e.pkg)
                        toInsert += UsageEventEntity(
                            id = 0, eventId = eventId,
                            packageName = e.pkg, appLabel = resolveLabel(e.pkg),
                            category = resolveCategory(e.pkg),
                            eventType = e.type, timeStamp = e.ts, durationMs = duration
                        )
                    }
                    23, 24 -> {
                        toInsert += UsageEventEntity(
                            id = 0, eventId = eventId,
                            packageName = e.pkg, appLabel = "", category = "",
                            eventType = e.type, timeStamp = e.ts, durationMs = 0L
                        )
                    }
                }
            }

            if (toInsert.isNotEmpty()) dao.insertAll(toInsert)

            delay(pollIntervalMs)
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun resolveLabel(packageName: String): String {
        if (packageName.isBlank()) return "Unknown"
        return try {
            val pm   = applicationContext.packageManager
            val info = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(info).toString()
        } catch (e: Exception) { packageName }
    }

    private fun resolveCategory(packageName: String): String {
        if (packageName.isBlank()) return "Unknown"
        return try {
            val pm   = applicationContext.packageManager
            val info = pm.getApplicationInfo(packageName, 0)
            when (info.category) {
                android.content.pm.ApplicationInfo.CATEGORY_SOCIAL       -> "Social"
                android.content.pm.ApplicationInfo.CATEGORY_GAME         -> "Game"
                android.content.pm.ApplicationInfo.CATEGORY_VIDEO        -> "Video"
                android.content.pm.ApplicationInfo.CATEGORY_NEWS         -> "News"
                android.content.pm.ApplicationInfo.CATEGORY_MAPS         -> "Maps"
                android.content.pm.ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Productivity"
                else -> "Other"
            }
        } catch (e: Exception) { "Unknown" }
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("PresencePulse")
            .setContentText("Monitoring app usage in background")
            .setSmallIcon(android.R.drawable.ic_menu_recent_history)
            .setOngoing(true)
            .setSilent(true)
            .build()

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID, "Usage Poller", NotificationManager.IMPORTANCE_LOW
        ).apply { description = "Keeps usage poller running in background" }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    companion object {
        private const val CHANNEL_ID = "usage_poller_channel"
        private const val NOTIF_ID   = 1001

        fun start(context: Context) {
            context.startForegroundService(Intent(context, UsagePollerService::class.java))
        }
        fun stop(context: Context) {
            context.stopService(Intent(context, UsagePollerService::class.java))
        }
    }
}