package com.blackbox.presencepulse.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.blackbox.presencepulse.navigation.Routes
import com.blackbox.presencepulse.ui.components.*
import com.blackbox.presencepulse.ui.theme.*

@Composable
fun NudgeScreen(onBack: () -> Unit, navController: NavController) {
    val nudgeTypes = listOf(
        Triple("🔔", "Gentle Remind",  "A soft ping to put the phone down"),
        Triple("💬", "Custom Message", "Send a personal note"),
        Triple("🎯", "Goal Alert",     "You're close to today's target!"),
        Triple("🏆", "Achievement",    "Celebrate a presence milestone"),
    )
    val states = remember { mutableStateListOf(true, true, false, true) }

    Scaffold(
        containerColor = BgPrimary,
        bottomBar = {
            BottomTabBar(current = TabDestination.Home) { dest ->
                when (dest) {
                    TabDestination.Home     -> navController.navigate(Routes.HOME) { popUpTo(Routes.HOME) }
                    TabDestination.Live     -> navController.navigate(Routes.DETECTION)
                    TabDestination.Insights -> navController.navigate(Routes.INSIGHTS)
                    TabDestination.Group    -> navController.navigate(Routes.GROUP_DASH)
                    TabDestination.Settings -> navController.navigate(Routes.PERSONALIZATION)
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                
                .verticalScroll(rememberScrollState())
        ) {
            
            TopNavBar(title = "Nudge", onBack = onBack)

            // Notification Card
            Column(
                modifier = Modifier
                    .padding(horizontal = 20.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Surface1)
                    .border(1.dp, Border2, RoundedCornerShape(20.dp))
            ) {
                // Top gradient bar
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .background(Brush.horizontalGradient(listOf(Accent, Cyan)))
                )
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.padding(bottom = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Brush.linearGradient(listOf(Accent, Color(0xFF5046E5)))),
                            contentAlignment = Alignment.Center
                        ) { Text("📡", fontSize = 18.sp) }
                        Column {
                            Text("PresencePulse", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
                            Text("just now", fontFamily = MonoFamily, fontSize = 10.sp, color = Muted)
                        }
                    }
                    Text(
                        "Hey Alex, your phone's been up for 23 mins 📱",
                        fontFamily = HeadingFamily, fontSize = 17.sp, fontWeight = FontWeight.Bold,
                        color = White, lineHeight = 24.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    Text(
                        "Priya is right there. Put it down and be present — you've got this.",
                        fontSize = 12.sp, color = TextSecondary, lineHeight = 18.sp,
                        modifier = Modifier.padding(bottom = 18.dp)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Surface2)
                                .border(1.dp, Border1, RoundedCornerShape(10.dp))
                                .clickable { onBack() }
                                .padding(vertical = 11.dp),
                            contentAlignment = Alignment.Center
                        ) { Text("Dismiss", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextSecondary) }

                        Box(
                            modifier = Modifier
                                .weight(1.5f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Brush.linearGradient(listOf(Accent, Color(0xFF5046E5))))
                                .clickable { onBack() }
                                .padding(vertical = 11.dp),
                            contentAlignment = Alignment.Center
                        ) { Text("I'm Present ✓", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = White) }
                    }
                }
            }

            // Stats
            SectionTitle("Today's Stats", modifier = Modifier.padding(horizontal = 20.dp))
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                data class StatItem(val value: String, val color: androidx.compose.ui.graphics.Color, val label: String)
                listOf(
                    StatItem("2",   Amber,  "Nudges"),
                    StatItem("47m", Green,  "Phone-Free"),
                    StatItem("92",  Accent, "Score")
                ).forEach { item ->
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Surface1)
                            .border(1.dp, Border1, RoundedCornerShape(14.dp))
                            .padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(item.value, fontFamily = HeadingFamily, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = item.color)
                        Text(item.label.uppercase(), fontSize = 9.sp, color = Muted, letterSpacing = 0.5.sp)
                    }
                }
            }

            // Nudge Types
            SectionTitle("Nudge Types", modifier = Modifier.padding(horizontal = 20.dp))
            Column(
                modifier = Modifier
                    .padding(horizontal = 20.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Surface1)
                    .border(1.dp, Border1, RoundedCornerShape(14.dp))
            ) {
                nudgeTypes.forEachIndexed { i, (icon, name, desc) ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(icon, fontSize = 22.sp, modifier = Modifier.width(38.dp))
                        Column(Modifier.weight(1f)) {
                            Text(name, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = White)
                            Text(desc, fontSize = 11.sp, color = Muted)
                        }
                        PPSwitch(checked = states[i], onCheckedChange = { states[i] = it })
                    }
                    if (i < nudgeTypes.lastIndex) {
                        Box(Modifier.fillMaxWidth().height(1.dp).background(Border1))
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
