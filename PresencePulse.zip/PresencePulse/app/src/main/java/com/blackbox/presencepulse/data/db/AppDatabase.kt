package com.blackbox.presencepulse.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        UsageEventEntity::class,
        AppCacheEntity::class,
        FriendCacheEntity::class,
        PhubEventEntity::class        // ← new
    ],
    version      = 3,                 // ← bumped
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun usageEventDao(): UsageEventDao
    abstract fun appCacheDao(): AppCacheDao
    abstract fun friendCacheDao(): FriendCacheDao
    abstract fun phubEventDao(): PhubEventDao   // ← new

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "presencepulse.db"
                )
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                    .also { INSTANCE = it }
            }
    }
}