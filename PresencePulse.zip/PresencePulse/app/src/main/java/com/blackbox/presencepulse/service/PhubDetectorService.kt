package com.blackbox.presencepulse.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.blackbox.presencepulse.R
import com.blackbox.presencepulse.ble.BleBackgroundService
import com.blackbox.presencepulse.data.db.AppDatabase
import com.blackbox.presencepulse.data.db.PhubEventEntity
import com.google.android.gms.location.ActivityRecognition
import com.google.android.gms.location.ActivityTransition
import com.google.android.gms.location.ActivityTransitionRequest
import com.google.android.gms.location.ActivityTransitionResult
import com.google.android.gms.location.DetectedActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class PhubDetectorService : Service() {

    private val scope = CoroutineScope(Dispatchers.IO + Job())

    private var currentActivity = DetectedActivity.STILL
    private var screenOnStartMs = 0L
    private var debounceActive  = false
    private var lastNudgeMs     = 0L

    private val DEBOUNCE_MS  = 90_000L
    private val COOLDOWN_MS  = 5 * 60_000L
    private val TIMEOUT_MS   = 30_000L

    private lateinit var dao          : com.blackbox.presencepulse.data.db.PhubEventDao
    private lateinit var usageManager : UsageStatsManager

    // ── Activity receiver ─────────────────────────────────────────────────────

    private val activityReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            ActivityTransitionResult.extractResult(intent)
                ?.transitionEvents?.lastOrNull()?.let {
                    currentActivity = it.activityType
                }
        }
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        dao          = AppDatabase.getInstance(this).phubEventDao()
        usageManager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager

        NudgeNotificationHelper.createChannel(this)
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())

        registerActivityReceiver()
        startActivityRecognition()
        startDetectionLoop()
        startTimeoutWatcher()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopActivityRecognition()
        try { unregisterReceiver(activityReceiver) } catch (_: Exception) {}
        scope.coroutineContext[Job]?.cancel()
        super.onDestroy()
    }

    // ── Detection loop ────────────────────────────────────────────────────────

    private fun startDetectionLoop() {
        scope.launch {
            BleBackgroundService.nearbyUidPrefixes.collect { prefixes ->
                evaluateState(prefixes)
            }
        }
        scope.launch {
            while (true) {
                delay(10_000L)
                evaluateState(BleBackgroundService.nearbyUidPrefixes.value)
            }
        }
    }

    private suspend fun evaluateState(nearbyPrefixes: Set<String>) {
        val screenOn   = isScreenOn()
        val blePresent = nearbyPrefixes.isNotEmpty()
        val isStill    = currentActivity == DetectedActivity.STILL ||
                currentActivity == DetectedActivity.UNKNOWN
        val inCooldown = (System.currentTimeMillis() - lastNudgeMs) < COOLDOWN_MS

        if (!screenOn || !blePresent || !isStill || inCooldown) {
            if (!screenOn || !blePresent) {
                screenOnStartMs = 0L
                debounceActive  = false
            }
            return
        }

        val now = System.currentTimeMillis()

        if (!debounceActive) {
            screenOnStartMs = now
            debounceActive  = true
            return
        }

        val screenOnDuration = now - screenOnStartMs
        if (screenOnDuration >= DEBOUNCE_MS) {
            debounceActive  = false
            screenOnStartMs = 0L
            lastNudgeMs     = now
            fireNudge(nearbyPrefixes, screenOnDuration)
        }
    }

    private suspend fun fireNudge(nearbyPrefixes: Set<String>, screenOnMs: Long) {
        val knownPrefixes = nearbyPrefixes.filter { !it.startsWith("rssi_") }
        val unknownCount  = nearbyPrefixes.count { it.startsWith("rssi_") }
        val knownCount    = knownPrefixes.size
        val socialContext = if (knownCount > 0) "known" else "unknown"
        val topPackage    = getForegroundApp()
        val topCategory   = resolveCategory(topPackage)
        val appName       = resolveAppName(topPackage)

        // Compute ML confidence heuristic
        val confidence = PhubScorer.computeConfidence(
            screenOnMs   = screenOnMs,
            knownCount   = knownCount,
            unknownCount = unknownCount,
            topCategory  = topCategory
        )

        val entity = PhubEventEntity(
            timestampMs   = System.currentTimeMillis(),
            confirmation  = "pending",
            socialContext = socialContext,
            knownCount    = knownCount,
            unknownCount  = unknownCount,
            screenOnMs    = screenOnMs,
            topPackage    = topPackage,
            topCategory   = topCategory,
            mlActivity    = activityName(currentActivity),
            mlConfidence  = confidence
        )
        val eventId = dao.insert(entity)

        NudgeNotificationHelper.fireNudge(
            context    = this,
            eventId    = eventId,
            appName    = appName,
            bleCount   = knownCount + unknownCount,
            screenOnMs = screenOnMs,
            confidence = confidence
        )
    }

    // ── Timeout watcher ───────────────────────────────────────────────────────

    private fun startTimeoutWatcher() {
        scope.launch {
            while (true) {
                delay(10_000L)
                val pending = dao.getPendingEvents()
                val now     = System.currentTimeMillis()
                pending.forEach { event ->
                    if (now - event.timestampMs >= TIMEOUT_MS) {
                        val score = PhubScorer.computeEventScore(
                            event.copy(confirmation = "timeout")
                        )
                        dao.update(event.copy(confirmation = "timeout", score = score))
                        NudgeNotificationHelper.cancelNudge(this@PhubDetectorService, event.id)
                    }
                }
            }
        }
    }

    // ── ML Kit Activity Recognition ───────────────────────────────────────────

    private fun startActivityRecognition() {
        val transitions = listOf(
            DetectedActivity.STILL, DetectedActivity.WALKING,
            DetectedActivity.RUNNING, DetectedActivity.IN_VEHICLE,
            DetectedActivity.ON_BICYCLE
        ).map { type ->
            ActivityTransition.Builder()
                .setActivityType(type)
                .setActivityTransition(ActivityTransition.ACTIVITY_TRANSITION_ENTER)
                .build()
        }

        val pi = android.app.PendingIntent.getBroadcast(
            this, 0,
            Intent(ACTIVITY_ACTION).apply { setPackage(packageName) },
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or
                    android.app.PendingIntent.FLAG_IMMUTABLE
        )
        try {
            ActivityRecognition.getClient(this)
                .requestActivityTransitionUpdates(ActivityTransitionRequest(transitions), pi)
        } catch (_: Exception) {}
    }

    private fun stopActivityRecognition() {
        val pi = android.app.PendingIntent.getBroadcast(
            this, 0,
            Intent(ACTIVITY_ACTION).apply { setPackage(packageName) },
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or
                    android.app.PendingIntent.FLAG_IMMUTABLE
        )
        try { ActivityRecognition.getClient(this).removeActivityTransitionUpdates(pi) }
        catch (_: Exception) {}
    }

    private fun registerActivityReceiver() {
        val filter = IntentFilter(ACTIVITY_ACTION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            registerReceiver(activityReceiver, filter, RECEIVER_NOT_EXPORTED)
        else
            registerReceiver(activityReceiver, filter)
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun isScreenOn(): Boolean {
        val pm = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
        return pm.isInteractive
    }

    private fun getForegroundApp(): String {
        return try {
            val now   = System.currentTimeMillis()
            val stats = usageManager.queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY, now - 5000, now
            )
            stats?.maxByOrNull { it.lastTimeUsed }?.packageName ?: ""
        } catch (_: Exception) { "" }
    }

    private fun resolveAppName(packageName: String): String {
        if (packageName.isBlank()) return ""
        return try {
            val info = packageManager.getApplicationInfo(packageName, 0)
            packageManager.getApplicationLabel(info).toString()
        } catch (_: Exception) { packageName }
    }

    private fun resolveCategory(packageName: String): String {
        if (packageName.isBlank()) return "Unknown"
        return try {
            val info = packageManager.getApplicationInfo(packageName, 0)
            when (info.category) {
                android.content.pm.ApplicationInfo.CATEGORY_SOCIAL       -> "Social"
                android.content.pm.ApplicationInfo.CATEGORY_GAME         -> "Game"
                android.content.pm.ApplicationInfo.CATEGORY_VIDEO        -> "Video"
                android.content.pm.ApplicationInfo.CATEGORY_NEWS         -> "News"
                android.content.pm.ApplicationInfo.CATEGORY_MAPS         -> "Maps"
                android.content.pm.ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Productivity"
                else -> "Other"
            }
        } catch (_: Exception) { "Unknown" }
    }

    private fun activityName(type: Int) = when (type) {
        DetectedActivity.STILL      -> "STILL"
        DetectedActivity.WALKING    -> "WALKING"
        DetectedActivity.RUNNING    -> "RUNNING"
        DetectedActivity.IN_VEHICLE -> "IN_VEHICLE"
        DetectedActivity.ON_BICYCLE -> "ON_BICYCLE"
        else                        -> "UNKNOWN"
    }

    // ── Notification ──────────────────────────────────────────────────────────

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_ID, "Phub Detector", NotificationManager.IMPORTANCE_MIN
            ).apply { setSound(null, null); enableVibration(false); setShowBadge(false) }
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("").setContentText("")
            .setSilent(true).setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET)
            .build()

    companion object {
        private const val CHANNEL_ID      = "pp_detector_channel"
        private const val NOTIF_ID        = 1002
        private const val ACTIVITY_ACTION = "com.blackbox.presencepulse.ACTIVITY_TRANSITION"

        fun start(context: Context) {
            val i = Intent(context, PhubDetectorService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                context.startForegroundService(i)
            else context.startService(i)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, PhubDetectorService::class.java))
        }
    }
}