package com.blackbox.presencepulse.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.blackbox.presencepulse.navigation.Routes
import com.blackbox.presencepulse.ui.components.*
import com.blackbox.presencepulse.ui.theme.*
import com.blackbox.presencepulse.viewmodel.DetectionViewModel
import com.blackbox.presencepulse.viewmodel.FriendInRange

@Composable
fun DetectionScreen(
    onBack        : () -> Unit,
    navController : NavController,
    viewModel     : DetectionViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    // No DisposableEffect here — BleBackgroundService manages its own lifecycle.
    // The service is already running before this screen opens and keeps running
    // after the user navigates away or turns the screen off.

    val timelineEvents = listOf(
        Triple("📱", "Phubbing Detected",  "09:14 AM"),
        Triple("✅", "Presence Restored",  "09:21 AM"),
        Triple("📡", "New Device Nearby",  "09:35 AM"),
        Triple("🔔", "Nudge Sent",         "10:02 AM"),
    )

    Scaffold(
        containerColor = BgPrimary,
        bottomBar = {
            BottomTabBar(current = TabDestination.Live) { dest ->
                when (dest) {
                    TabDestination.Home     -> navController.navigate(Routes.HOME) { popUpTo(Routes.HOME) }
                    TabDestination.Insights -> navController.navigate(Routes.INSIGHTS)
                    TabDestination.Group    -> navController.navigate(Routes.GROUP_DASH)
                    TabDestination.Settings -> navController.navigate(Routes.PERSONALIZATION)
                    else -> {}
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
        ) {
            TopNavBar(title = "Live Detection", onBack = onBack)

            // ── Radar Hero ────────────────────────────────────────────────
            Box(
                modifier = Modifier
                    .padding(horizontal = 20.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Surface1)
                    .border(1.dp, Border1, RoundedCornerShape(20.dp)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    modifier            = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    RadarAnimation()
                    Spacer(Modifier.height(14.dp))
                    Text(
                        "Phone Down — Present",
                        fontFamily = HeadingFamily,
                        fontSize   = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color      = White
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "${uiState.totalBleCount} PresencePulse device${if (uiState.totalBleCount == 1) "" else "s"} · ${uiState.friendsInRange.size} friend${if (uiState.friendsInRange.size == 1) "" else "s"} in range",
                        fontSize = 11.sp,
                        color    = TextSecondary
                    )
                    Spacer(Modifier.height(12.dp))
                    PPChip(
                        if (uiState.isScanning) "SCANNING" else "IDLE",
                        if (uiState.isScanning) ChipStyle.GREEN else ChipStyle.ACCENT
                    )
                }
            }

            // ── BLE Counter Card ──────────────────────────────────────────
            SectionTitle(
                "Nearby PresencePulse Devices",
                modifier = Modifier.padding(horizontal = 20.dp)
            )
            Row(
                modifier = Modifier
                    .padding(horizontal = 20.dp, vertical = 4.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Surface1)
                    .border(1.dp, Border1, RoundedCornerShape(16.dp))
                    .padding(16.dp),
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Accent, Color(0xFF5046E5)))),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "${uiState.totalBleCount}",
                        fontSize   = 22.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color      = White
                    )
                }
                Column {
                    Text(
                        "Phones with PresencePulse",
                        fontSize   = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color      = White
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        if (uiState.isScanning || uiState.totalBleCount > 0) "Running in background · screen off supported"
                        else                              "Service not running",
                        fontSize = 11.sp,
                        color    = TextSecondary
                    )
                }
            }

            // ── Friends in Range ──────────────────────────────────────────
            SectionTitle(
                "Friends in Range  •  ${uiState.friendsInRange.size}",
                modifier = Modifier.padding(horizontal = 20.dp)
            )

            if (uiState.friendsInRange.isEmpty()) {
                Box(
                    modifier = Modifier
                        .padding(horizontal = 20.dp, vertical = 4.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Surface1)
                        .border(1.dp, Border1, RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Text(
                        "No friends nearby yet. Add friends via the Group tab.",
                        fontSize   = 12.sp,
                        color      = TextSecondary,
                        lineHeight = 18.sp
                    )
                }
            } else {
                uiState.friendsInRange.forEach { friend ->
                    FriendInRangeRow(friend = friend)
                }
            }

            // ── Timeline ──────────────────────────────────────────────────
            SectionTitle(
                "Today's Timeline",
                modifier = Modifier.padding(horizontal = 20.dp)
            )
            Column(modifier = Modifier.padding(horizontal = 20.dp)) {
                timelineEvents.forEachIndexed { i, (icon, title, time) ->
                    TimelineItem(
                        icon   = icon,
                        title  = title,
                        time   = time,
                        isLast = i == timelineEvents.lastIndex
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun FriendInRangeRow(friend: FriendInRange) {
    Row(
        modifier = Modifier
            .padding(horizontal = 20.dp, vertical = 4.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Surface1)
            .border(1.dp, Border1, RoundedCornerShape(12.dp))
            .padding(12.dp),
        verticalAlignment     = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Accent, Color(0xFF5046E5)))),
            contentAlignment = Alignment.Center
        ) {
            Text(
                friend.name.take(1).uppercase(),
                fontSize   = 14.sp,
                fontWeight = FontWeight.Bold,
                color      = White
            )
        }
        Text(
            friend.name,
            fontSize   = 13.sp,
            fontWeight = FontWeight.Medium,
            color      = White,
            modifier   = Modifier.weight(1f)
        )
        PPChip("IN RANGE", ChipStyle.GREEN)
    }
}

@Composable
private fun RadarAnimation() {
    val t  = rememberInfiniteTransition(label = "radar")
    val p1 by t.animateFloat(0.85f, 1f, infiniteRepeatable(tween(2000), RepeatMode.Reverse), label = "p1")
    val p2 by t.animateFloat(0.85f, 1f, infiniteRepeatable(tween(2000, delayMillis = 400), RepeatMode.Reverse), label = "p2")
    val p3 by t.animateFloat(0.85f, 1f, infiniteRepeatable(tween(2000, delayMillis = 800), RepeatMode.Reverse), label = "p3")

    Box(modifier = Modifier.size(110.dp), contentAlignment = Alignment.Center) {
        Box(Modifier.size(110.dp).scale(p1).clip(CircleShape).border(1.dp, Accent.copy(alpha = 0.2f), CircleShape))
        Box(Modifier.size(80.dp).scale(p2).clip(CircleShape).border(1.dp, Accent.copy(alpha = 0.3f), CircleShape))
        Box(Modifier.size(50.dp).scale(p3).clip(CircleShape).border(1.dp, Accent.copy(alpha = 0.4f), CircleShape))
        Box(
            modifier = Modifier.size(30.dp).clip(CircleShape)
                .background(Brush.linearGradient(listOf(Accent, Color(0xFF5046E5)))),
            contentAlignment = Alignment.Center
        ) { Text("📡", fontSize = 13.sp) }
    }
}

@Composable
private fun TimelineItem(icon: String, title: String, time: String, isLast: Boolean) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier.size(30.dp).clip(CircleShape).background(Surface2),
                contentAlignment = Alignment.Center
            ) { Text(icon, fontSize = 13.sp) }
            if (!isLast) Box(Modifier.width(1.dp).height(28.dp).background(Border1))
        }
        Column(Modifier.padding(top = 4.dp, bottom = if (isLast) 0.dp else 4.dp)) {
            Text(title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = White)
            Text(time, fontFamily = MonoFamily, fontSize = 10.sp, color = Muted, modifier = Modifier.padding(top = 2.dp))
        }
    }
}