package com.blackbox.presencepulse.firebase

import android.content.Context
import com.blackbox.presencepulse.data.db.AppDatabase
import com.blackbox.presencepulse.data.db.FriendCacheEntity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

// ── Data models ───────────────────────────────────────────────────────────────

data class UserSearchResult(
    val uid   : String = "",
    val name  : String = "",
    val email : String = ""
)

data class FriendRequest(
    val requestId : String = "",
    val fromUid   : String = "",
    val fromName  : String = "",
    val toUid     : String = "",
    val toName    : String = "",
    val status    : String = "pending"
)

data class Friend(
    val uid  : String = "",
    val name : String = ""
)

// ── Repository ────────────────────────────────────────────────────────────────

class FriendRepository(private val context: Context) {

    private val db   = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val dao  by lazy { AppDatabase.getInstance(context).friendCacheDao() }
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val currentUid  get() = auth.currentUser?.uid ?: ""
    private val currentName get() = auth.currentUser?.displayName ?: ""

    // ── Search user by email ──────────────────────────────────────────────────

    suspend fun searchByEmail(email: String): UserSearchResult? {
        if (email.isBlank()) return null
        val trimmed = email.trim()
        return try {
            for (candidate in listOf(trimmed, trimmed.lowercase()).distinct()) {
                val snap = db.collection("users")
                    .whereEqualTo("email", candidate)
                    .limit(1)
                    .get()
                    .await()
                val doc  = snap.documents.firstOrNull() ?: continue
                val uid  = doc.getString("uid")   ?: continue
                val name = doc.getString("name")  ?: continue
                val mail = doc.getString("email") ?: continue
                return UserSearchResult(uid = uid, name = name, email = mail)
            }
            null
        } catch (e: Exception) { null }
    }

    // ── Send friend request ───────────────────────────────────────────────────

    suspend fun sendFriendRequest(toUid: String, toName: String): Result<Unit> {
        if (currentUid.isEmpty()) return Result.failure(Exception("Not logged in"))
        if (toUid == currentUid)  return Result.failure(Exception("Cannot add yourself"))
        val docId = "${currentUid}_${toUid}"
        return try {
            db.collection("friendRequests").document(docId).set(
                mapOf(
                    "requestId" to docId,
                    "fromUid"   to currentUid,
                    "fromName"  to currentName,
                    "toUid"     to toUid,
                    "toName"    to toName,
                    "status"    to "pending",
                    "createdAt" to System.currentTimeMillis()
                )
            ).await()
            Result.success(Unit)
        } catch (e: Exception) { Result.failure(e) }
    }

    // ── Accept friend request ─────────────────────────────────────────────────

    suspend fun acceptRequest(request: FriendRequest): Result<Unit> {
        return try {
            db.collection("users").document(currentUid)
                .collection("friends").document(request.fromUid)
                .set(mapOf("uid" to request.fromUid, "name" to request.fromName))
                .await()
            db.collection("friendRequests").document(request.requestId)
                .set(mapOf(
                    "requestId" to request.requestId,
                    "fromUid"   to request.fromUid,
                    "fromName"  to request.fromName,
                    "toUid"     to request.toUid,
                    "toName"    to request.toName,
                    "status"    to "accepted",
                    "createdAt" to System.currentTimeMillis()
                )).await()
            Result.success(Unit)
        } catch (e: Exception) { Result.failure(e) }
    }

    // ── Reject request ────────────────────────────────────────────────────────

    suspend fun rejectRequest(requestId: String): Result<Unit> {
        return try {
            db.collection("friendRequests").document(requestId).delete().await()
            Result.success(Unit)
        } catch (e: Exception) { Result.failure(e) }
    }

    // ── Finalise friendship (sender side) ─────────────────────────────────────

    suspend fun finaliseFriendship(request: FriendRequest): Result<Unit> {
        return try {
            db.collection("users").document(currentUid)
                .collection("friends").document(request.toUid)
                .set(mapOf("uid" to request.toUid, "name" to request.toName))
                .await()
            db.collection("friendRequests").document(request.requestId)
                .delete().await()
            Result.success(Unit)
        } catch (e: Exception) { Result.failure(e) }
    }

    // ── Incoming pending requests ─────────────────────────────────────────────

    fun incomingRequestsFlow(): Flow<List<FriendRequest>> = callbackFlow {
        var reg: ListenerRegistration? = null
        if (currentUid.isNotEmpty()) {
            reg = db.collection("friendRequests")
                .whereEqualTo("toUid", currentUid)
                .whereEqualTo("status", "pending")
                .addSnapshotListener { snap, _ ->
                    val list = snap?.documents?.mapNotNull { doc ->
                        FriendRequest(
                            requestId = doc.getString("requestId") ?: return@mapNotNull null,
                            fromUid   = doc.getString("fromUid")   ?: return@mapNotNull null,
                            fromName  = doc.getString("fromName")  ?: return@mapNotNull null,
                            toUid     = doc.getString("toUid")     ?: return@mapNotNull null,
                            toName    = doc.getString("toName")    ?: "",
                            status    = doc.getString("status")    ?: "pending"
                        )
                    } ?: emptyList()
                    trySend(list)
                }
        }
        awaitClose { reg?.remove() }
    }

    // ── Accepted sent requests ────────────────────────────────────────────────

    fun acceptedSentRequestsFlow(): Flow<List<FriendRequest>> = callbackFlow {
        var reg: ListenerRegistration? = null
        if (currentUid.isNotEmpty()) {
            reg = db.collection("friendRequests")
                .whereEqualTo("fromUid", currentUid)
                .whereEqualTo("status", "accepted")
                .addSnapshotListener { snap, _ ->
                    val list = snap?.documents?.mapNotNull { doc ->
                        FriendRequest(
                            requestId = doc.getString("requestId") ?: return@mapNotNull null,
                            fromUid   = doc.getString("fromUid")   ?: return@mapNotNull null,
                            fromName  = doc.getString("fromName")  ?: return@mapNotNull null,
                            toUid     = doc.getString("toUid")     ?: return@mapNotNull null,
                            toName    = doc.getString("toName")    ?: "",
                            status    = "accepted"
                        )
                    } ?: emptyList()
                    trySend(list)
                }
        }
        awaitClose { reg?.remove() }
    }

    // ── Friends flow with offline cache ──────────────────────────────────────
    //
    // Flow behaviour:
    //  • ONLINE : Firestore listener fires → cache written to Room → fresh list emitted
    //  • OFFLINE: Firestore listener fails silently → cached Room data emitted instantly
    //
    // This means detection always works even with no internet after first load.

    fun friendsFlow(): Flow<List<Friend>> = callbackFlow {
        // Emit Room cache immediately — works offline, zero latency
        val cached = dao.getAll().map { Friend(uid = it.uid, name = it.name) }
        if (cached.isNotEmpty()) trySend(cached)

        // Attach Firestore listener for live updates when online
        var reg: ListenerRegistration? = null
        if (currentUid.isNotEmpty()) {
            reg = db.collection("users")
                .document(currentUid)
                .collection("friends")
                .addSnapshotListener { snap, error ->
                    // Silently ignore offline errors — cache already emitted above
                    if (error != null || snap == null) return@addSnapshotListener

                    val friends = snap.documents.mapNotNull { doc ->
                        Friend(
                            uid  = doc.getString("uid")  ?: return@mapNotNull null,
                            name = doc.getString("name") ?: return@mapNotNull null
                        )
                    }

                    // Write fresh list to Room cache (IO thread, fire and forget)
                    ioScope.launch {
                        dao.clearAll()
                        dao.insertAll(friends.map {
                            FriendCacheEntity(uid = it.uid, name = it.name)
                        })
                    }

                    trySend(friends)
                }
        }
        awaitClose { reg?.remove() }
    }
}