package com.blackbox.presencepulse.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Use system fonts; in a real project you'd add Syne & DM Sans via res/font/
val HeadingFamily = FontFamily.Default
val BodyFamily    = FontFamily.Default
val MonoFamily    = FontFamily.Monospace

val PresencePulseTypography = Typography(
    displayLarge  = TextStyle(fontFamily = HeadingFamily, fontWeight = FontWeight.ExtraBold, fontSize = 38.sp, letterSpacing = (-1.5).sp, color = White),
    headlineLarge = TextStyle(fontFamily = HeadingFamily, fontWeight = FontWeight.ExtraBold, fontSize = 28.sp, letterSpacing = (-0.8).sp, color = White),
    headlineMedium= TextStyle(fontFamily = HeadingFamily, fontWeight = FontWeight.Bold,      fontSize = 20.sp, letterSpacing = (-0.3).sp, color = White),
    titleLarge    = TextStyle(fontFamily = HeadingFamily, fontWeight = FontWeight.Bold,      fontSize = 17.sp, color = White),
    titleMedium   = TextStyle(fontFamily = HeadingFamily, fontWeight = FontWeight.SemiBold,  fontSize = 14.sp, color = White),
    bodyLarge     = TextStyle(fontFamily = BodyFamily,    fontWeight = FontWeight.Normal,     fontSize = 14.sp, color = White),
    bodyMedium    = TextStyle(fontFamily = BodyFamily,    fontWeight = FontWeight.Normal,     fontSize = 13.sp, color = TextSecondary),
    bodySmall     = TextStyle(fontFamily = BodyFamily,    fontWeight = FontWeight.Normal,     fontSize = 11.sp, color = TextSecondary),
    labelSmall    = TextStyle(fontFamily = BodyFamily,    fontWeight = FontWeight.SemiBold,   fontSize = 9.sp,  letterSpacing = 1.sp, color = Muted),
)
