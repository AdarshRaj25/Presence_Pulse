package com.blackbox.presencepulse.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.blackbox.presencepulse.network.rememberIsOnline
import com.blackbox.presencepulse.ui.components.*
import com.blackbox.presencepulse.ui.theme.*

private val AUTH_TOP_PADDING = 42.dp

// ═══════════════════════════════════════════════════════════════
// SIGN UP SCREEN
// ═══════════════════════════════════════════════════════════════

@Composable
fun SignUpScreen(
    onSignUpSuccess: () -> Unit,
    onNavigateToLogin: (email: String) -> Unit,
    authViewModel: AuthViewModel = viewModel()
) {
    var name     by remember { mutableStateOf("") }
    var email    by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    val uiState  by authViewModel.signUpState.collectAsStateWithLifecycle()
    val isOnline by rememberIsOnline()

    // Collect the one-shot SharedFlow — fires exactly once after Firebase
    // confirms success, never replays on recomposition or screen re-entry.
    LaunchedEffect(Unit) {
        authViewModel.signUpSuccess.collect { onSignUpSuccess() }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BgPrimary)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {
            Column(
                modifier = Modifier
                    .padding(horizontal = 20.dp)
                    .padding(top = AUTH_TOP_PADDING)
            ) {
                Text(
                    "Create account",
                    fontFamily = HeadingFamily,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = (-0.8).sp,
                    color = White
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "Start your journey to mindful presence.",
                    fontSize = 13.sp,
                    color = TextSecondary,
                    lineHeight = 20.sp,
                    modifier = Modifier.padding(bottom = 28.dp)
                )

                PPTextField(
                    value = name,
                    onValueChange = { name = it; authViewModel.clearSignUpError() },
                    label = "Full Name",
                    placeholder = "Alex Johnson"
                )
                Spacer(Modifier.height(14.dp))
                PPTextField(
                    value = email,
                    onValueChange = { email = it; authViewModel.clearSignUpError() },
                    label = "Email",
                    placeholder = "you@example.com"
                )
                Spacer(Modifier.height(14.dp))
                PPTextField(
                    value = password,
                    onValueChange = { password = it; authViewModel.clearSignUpError() },
                    label = "Password",
                    placeholder = "........",
                    isPassword = true
                )

                // ── Already registered prompt ──────────────────────────────
                if (uiState.emailAlreadyExists) {
                    Spacer(Modifier.height(12.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Accent.copy(alpha = 0.08f))
                            .border(1.dp, Accent.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
                            .padding(horizontal = 14.dp, vertical = 12.dp)
                    ) {
                        Text(
                            "This email is already registered.",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = White
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Want to log in with this email instead?",
                            fontSize = 11.sp,
                            color = TextSecondary,
                            lineHeight = 16.sp
                        )
                        Spacer(Modifier.height(10.dp))
                        TextButton(
                            onClick = { onNavigateToLogin(email) },
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text(
                                "Log In instead →",
                                fontSize = 12.sp,
                                color = Accent,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // ── Generic error ──────────────────────────────────────────
                uiState.errorMessage?.let { error ->
                    Spacer(Modifier.height(12.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Red.copy(alpha = 0.12f))
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Text("⚠ $error", fontSize = 12.sp, color = Red, lineHeight = 18.sp)
                    }
                }

                Spacer(Modifier.height(24.dp))

                if (uiState.isLoading) {
                    Box(
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = Accent, strokeWidth = 2.dp)
                    }
                } else {
                    PrimaryButton(
                        label = "Create Account",
                        onClick = { if (isOnline) authViewModel.signUp(name, email, password) },
                        modifier = Modifier.alpha(if (isOnline) 1f else 0.45f)
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            TextButton(
                onClick = { onNavigateToLogin("") },
                enabled = !uiState.isLoading,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp)
            ) {
                Text(
                    buildAnnotatedString {
                        append("Already have an account? ")
                        withStyle(SpanStyle(color = Accent, fontWeight = FontWeight.SemiBold)) {
                            append("Log In")
                        }
                    },
                    textAlign = TextAlign.Center,
                    fontSize = 12.sp,
                    color = Muted
                )
            }
        }

        NoInternetBanner(
            isOnline = isOnline,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

// ═══════════════════════════════════════════════════════════════
// LOGIN SCREEN
// ═══════════════════════════════════════════════════════════════

@Composable
fun LoginScreen(
    onLoginSuccess: () -> Unit,
    onNavigateToSignUp: () -> Unit,
    prefillEmail: String = "",
    authViewModel: AuthViewModel = viewModel()
) {
    var email    by remember { mutableStateOf(prefillEmail) }
    var password by remember { mutableStateOf("") }

    val uiState    by authViewModel.loginState.collectAsStateWithLifecycle()
    val resetState by authViewModel.resetState.collectAsStateWithLifecycle()
    val isOnline   by rememberIsOnline()

    // Same one-shot pattern — collects exactly once per login attempt.
    LaunchedEffect(Unit) {
        authViewModel.loginSuccess.collect { onLoginSuccess() }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BgPrimary)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {
            Column(
                modifier = Modifier
                    .padding(horizontal = 20.dp)
                    .padding(top = AUTH_TOP_PADDING)
            ) {
                Text(
                    "Welcome back",
                    fontFamily = HeadingFamily,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = (-0.8).sp,
                    color = White
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "Good to see you. Let's check in.",
                    fontSize = 13.sp,
                    color = TextSecondary,
                    lineHeight = 20.sp,
                    modifier = Modifier.padding(bottom = 28.dp)
                )

                PPTextField(
                    value = email,
                    onValueChange = {
                        email = it
                        authViewModel.clearLoginError()
                        authViewModel.clearResetState()
                    },
                    label = "Email",
                    placeholder = "you@example.com"
                )
                Spacer(Modifier.height(14.dp))
                PPTextField(
                    value = password,
                    onValueChange = { password = it; authViewModel.clearLoginError() },
                    label = "Password",
                    placeholder = "........",
                    isPassword = true
                )

                Spacer(Modifier.height(12.dp))

                TextButton(
                    onClick = { authViewModel.sendPasswordReset(email) },
                    enabled = !uiState.isLoading,
                    contentPadding = PaddingValues(horizontal = 0.dp, vertical = 4.dp)
                ) {
                    Text(
                        "Forgot password?",
                        fontSize = 12.sp,
                        color = Accent,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                resetState.message?.let { msg ->
                    Spacer(Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (resetState.isError) Red.copy(alpha = 0.12f)
                                else Green.copy(alpha = 0.12f)
                            )
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Text(
                            msg,
                            fontSize = 12.sp,
                            color = if (resetState.isError) Red else Green,
                            lineHeight = 18.sp
                        )
                    }
                }

                uiState.errorMessage?.let { error ->
                    Spacer(Modifier.height(10.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Red.copy(alpha = 0.12f))
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Text("⚠ $error", fontSize = 12.sp, color = Red, lineHeight = 18.sp)
                    }
                }

                Spacer(Modifier.height(20.dp))

                if (uiState.isLoading) {
                    Box(
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = Accent, strokeWidth = 2.dp)
                    }
                } else {
                    PrimaryButton(
                        label = "Log In",
                        onClick = { if (isOnline) authViewModel.login(email, password) },
                        modifier = Modifier.alpha(if (isOnline) 1f else 0.45f)
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            TextButton(
                onClick = onNavigateToSignUp,
                enabled = !uiState.isLoading,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp)
            ) {
                Text(
                    buildAnnotatedString {
                        append("Don't have an account? ")
                        withStyle(SpanStyle(color = Accent, fontWeight = FontWeight.SemiBold)) {
                            append("Sign Up")
                        }
                    },
                    textAlign = TextAlign.Center,
                    fontSize = 12.sp,
                    color = Muted
                )
            }
        }

        NoInternetBanner(
            isOnline = isOnline,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}