package com.blackbox.presencepulse.data.repository

import android.content.Context
import com.blackbox.presencepulse.ble.BleBackgroundService
import com.blackbox.presencepulse.data.db.AppDatabase
import com.blackbox.presencepulse.data.db.TopPhubApp
import com.blackbox.presencepulse.service.PhubScorer
import java.util.Calendar

class UsageRepository(private val context: Context) {

    private val usageDao = AppDatabase.getInstance(context).usageEventDao()
    private val phubDao  = AppDatabase.getInstance(context).phubEventDao()

    // ── Time helpers ──────────────────────────────────────────────────────────

    fun todayStartMs(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0);      set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    fun weekStartMs(): Long = Calendar.getInstance().apply {
        set(Calendar.DAY_OF_WEEK, firstDayOfWeek)
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0);      set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    // ── Today's metrics ───────────────────────────────────────────────────────

    /**
     * Computes total screen-on time today directly from UsageStatsManager
     * queryUsageStats — this is the most accurate source, giving total
     * foreground time per app aggregated by the OS itself.
     * We sum totalTimeInForeground across all non-system apps.
     *
     * Falls back to screen event pairing if UsageStats returns nothing.
     */
    /**
     * Computes screen-on time by walking raw ACTIVITY_RESUMED (1) +
     * ACTIVITY_PAUSED (2) events from UsageStatsManager queryEvents().
     *
     * This is the most accurate approach because:
     * - queryUsageStats INTERVAL_DAILY can accumulate across midnight on some OEMs
     * - queryUsageStats counts background service time as foreground on some devices
     * - Raw events give us exact timestamps of when each app was visible on screen
     *
     * We exclude our own package so viewing the HomeScreen doesn't inflate the count.
     */
    fun getTodayScreenOnMs(): Long {
        return try {
            val usm = context.getSystemService(android.content.Context.USAGE_STATS_SERVICE)
                    as android.app.usage.UsageStatsManager

            val usageEvents = usm.queryEvents(todayStartMs(), System.currentTimeMillis())
            val event       = android.app.usage.UsageEvents.Event()

            // resumeMap: packageName → time of last ACTIVITY_RESUMED
            val resumeMap = mutableMapOf<String, Long>()
            var totalMs   = 0L

            // Packages that are never real user screen time:
            // - Our own app (always resumed while user views HomeScreen)
            // - System UI and launchers
            val excluded = setOf(
                context.packageName,
                "com.android.systemui",
                "com.android.launcher3",
                "com.google.android.apps.nexuslauncher",
                "com.miui.home",
                "com.sec.android.app.launcher",
                "com.oneplus.launcher",
                "com.huawei.android.launcher",
                "com.vivo.launcher",
                "com.oppo.launcher"
            )

            while (usageEvents.hasNextEvent()) {
                usageEvents.getNextEvent(event)
                val pkg = event.packageName ?: continue
                if (pkg in excluded) continue

                when (event.eventType) {
                    1 -> resumeMap[pkg] = event.timeStamp  // ACTIVITY_RESUMED
                    2 -> {                                  // ACTIVITY_PAUSED
                        val resumeTime = resumeMap.remove(pkg)
                        if (resumeTime != null) {
                            val duration = event.timeStamp - resumeTime
                            // Only count sessions > 2 seconds — filters notification
                            // previews and service wakeups that aren't real screen usage
                            if (duration > 2_000L) totalMs += duration
                        }
                    }
                }
            }

            // Any app still in foreground — count until now
            val now = System.currentTimeMillis()
            resumeMap.forEach { (_, resumeTime) ->
                val duration = now - resumeTime
                if (duration > 2_000L) totalMs += duration
            }

            totalMs
        } catch (_: Exception) { 0L }
    }

    /**
     * Returns unlock count using UsageStatsManager directly.
     * KEYGUARD_HIDDEN (event type 2) = phone unlocked — matches Digital Wellbeing "Unlocks".
     * Falls back to SCREEN_ON events from Room if UsageStats unavailable.
     */
    fun getTodayPickupCount(): Int {
        return try {
            val usm = context.getSystemService(android.content.Context.USAGE_STATS_SERVICE)
                    as android.app.usage.UsageStatsManager
            val usageEvents = usm.queryEvents(todayStartMs(), System.currentTimeMillis())
            val event       = android.app.usage.UsageEvents.Event()
            var count       = 0
            while (usageEvents.hasNextEvent()) {
                usageEvents.getNextEvent(event)
                // KEYGUARD_HIDDEN = 18 = device unlocked (matches Digital Wellbeing unlocks)
                if (event.eventType == 18) count++
            }
            count
        } catch (_: Exception) { 0 }
    }

    // ── Score + phub count from confirmed events ──────────────────────────────

    suspend fun getTodayScoreAndCount(): Pair<Int, Int> {
        val events = phubDao.getConfirmedSince(todayStartMs())
        return PhubScorer.computeDailyScore(events)
    }

    // ── Streak ────────────────────────────────────────────────────────────────

    suspend fun getCurrentStreak(): Int {
        var streak    = 0
        val cal       = Calendar.getInstance()

        // Start from yesterday (offset=1) — today is in progress so we don't
        // count it unless it already has at least one confirmed event.
        // This prevents a fresh install from showing a streak > 0 immediately.

        // Check today first — only counts if there are confirmed events
        val todayStart = todayStartMs()
        val todayEnd   = todayStart + 86_400_000L
        val todayEvents = phubDao.getConfirmedSince(todayStart)
            .filter { it.timestampMs < todayEnd }

        if (todayEvents.isNotEmpty()) {
            val (todayScore, _) = PhubScorer.computeDailyScore(todayEvents)
            if (todayScore >= 70) streak++
        }
        // If today has no events at all, it's still in progress — don't break streak

        // Now walk backwards through completed past days
        var dayOffset = 1
        while (dayOffset < 30) {
            cal.timeInMillis = System.currentTimeMillis()
            cal.add(Calendar.DAY_OF_YEAR, -dayOffset)
            cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0);      cal.set(Calendar.MILLISECOND, 0)
            val dayStart = cal.timeInMillis
            val dayEnd   = dayStart + 86_400_000L

            val events = phubDao.getConfirmedSince(dayStart)
                .filter { it.timestampMs < dayEnd }

            if (events.isEmpty()) {
                // No events on this past day — streak broken
                break
            }

            val (score, _) = PhubScorer.computeDailyScore(events)
            if (score >= 70) streak++ else break
            dayOffset++
        }
        return streak
    }

    // ── Weekly scores for bar chart ───────────────────────────────────────────

    suspend fun getWeeklyScores(): List<Pair<String, Float>> {
        val dayLabels = listOf("M", "T", "W", "T", "F", "S", "S")
        val cal       = Calendar.getInstance()
        val scores    = mutableMapOf<Int, Float>()

        for (i in 6 downTo 0) {
            cal.timeInMillis = System.currentTimeMillis()
            cal.add(Calendar.DAY_OF_YEAR, -i)
            cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0);      cal.set(Calendar.MILLISECOND, 0)
            val dayStart = cal.timeInMillis
            val dayEnd   = dayStart + 86_400_000L
            val dow      = (cal.get(Calendar.DAY_OF_WEEK) - 2 + 7) % 7

            val events    = phubDao.getConfirmedSince(dayStart)
                .filter { it.timestampMs < dayEnd }
            val (score, _) = PhubScorer.computeDailyScore(events)
            scores[dow]   = score.toFloat()
        }

        return dayLabels.mapIndexed { i, label -> Pair(label, scores[i] ?: 50f) }
    }

    // ── Heatmap (28 days) ─────────────────────────────────────────────────────

    suspend fun getHeatmapData(): List<Float> {
        val cal = Calendar.getInstance()
        return (27 downTo 0).map { offset ->
            cal.timeInMillis = System.currentTimeMillis()
            cal.add(Calendar.DAY_OF_YEAR, -offset)
            cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0);      cal.set(Calendar.MILLISECOND, 0)
            val dayStart = cal.timeInMillis
            val dayEnd   = dayStart + 86_400_000L

            val events    = phubDao.getConfirmedSince(dayStart)
                .filter { it.timestampMs < dayEnd }
            val (score, _) = PhubScorer.computeDailyScore(events)
            score / 100f
        }
    }

    // ── Top phubbing apps for pattern insight ─────────────────────────────────

    suspend fun getTopPhubApps(): List<TopPhubApp> =
        phubDao.topPhubAppsSince(weekStartMs())

    // ── Key insights ──────────────────────────────────────────────────────────

    suspend fun getKeyInsights(): List<Triple<String, String, String>> {
        val (score, phubCount) = getTodayScoreAndCount()
        val pickups            = getTodayPickupCount()
        val streak             = getCurrentStreak()
        val socialMins         = com.blackbox.presencepulse.ble.BleBackgroundService.socialMinutesToday.value
        val topApps            = getTopPhubApps()
        val insights           = mutableListOf<Triple<String, String, String>>()

        // Streak
        if (streak > 0)
            insights += Triple("🔥", "Current Streak", "$streak day${if (streak == 1) "" else "s"} of good presence")

        // Score context
        insights += Triple(
            "🎯", "Today's Score",
            when {
                score >= 85 -> "Excellent — minimal phubbing"
                score >= 70 -> "Good presence today"
                score >= 50 -> "Some phubbing detected"
                else        -> "High phubbing — $phubCount event${if (phubCount == 1) "" else "s"}"
            }
        )

        // Pickup count
        insights += Triple(
            "📱", "Phone Pickups",
            when {
                pickups <= 10 -> "Only $pickups pickups — great focus"
                pickups <= 25 -> "$pickups pickups today"
                else          -> "$pickups pickups — try to reduce"
            }
        )

        // Top phubbing app this week
        topApps.firstOrNull()?.let { app ->
            val label = if (app.topCategory != "Unknown") app.topCategory else app.topPackage
            insights += Triple("📊", "Top Distraction", "$label · ${app.count}× this week")
        }

        // Screen time
        val socialLabel = when {
            socialMins == 0  -> "No social time detected yet"
            socialMins < 30  -> "$socialMins min with others nearby"
            socialMins < 60  -> "$socialMins min social time today"
            else             -> "${socialMins / 60}h ${socialMins % 60}m with others"
        }
        insights += Triple("👥", "Social Time", socialLabel)

        return insights
    }
}