package com.blackbox.presencepulse.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.blackbox.presencepulse.navigation.Routes
import com.blackbox.presencepulse.ui.components.*
import com.blackbox.presencepulse.ui.theme.*
import com.blackbox.presencepulse.viewmodel.InsightsViewModel
import com.blackbox.presencepulse.viewmodel.ScoreColor
import java.util.Calendar

@Composable
fun HomeScreen(
    navController     : NavController,
    authViewModel     : AuthViewModel     = viewModel(),
    insightsViewModel : InsightsViewModel = viewModel()
) {
    val displayNameFull by authViewModel.displayName.collectAsStateWithLifecycle()
    val uiState         by insightsViewModel.uiState.collectAsStateWithLifecycle()

    val displayName = remember(displayNameFull) {
        displayNameFull.trim().split(" ").firstOrNull()?.ifBlank { null } ?: "there"
    }

    val greeting = remember {
        when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
            in 5..11  -> "Good morning,"
            in 12..16 -> "Good afternoon,"
            in 17..20 -> "Good evening,"
            else      -> "Good night,"
        }
    }

    // Reload scores every time screen becomes visible —
    // catches score changes from NudgeOverlayActivity writing to Room
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                insightsViewModel.loadAll()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    var showNameDialog by remember { mutableStateOf(false) }

    if (showNameDialog) {
        ChangeNameDialog(
            currentName = displayNameFull,
            onDismiss   = { showNameDialog = false },
            onConfirm   = { newName ->
                authViewModel.updateDisplayName(newName) { showNameDialog = false }
            }
        )
    }

    val scoreAccent = when (uiState.scoreColor) {
        ScoreColor.GREAT   -> Green
        ScoreColor.GOOD    -> Accent
        ScoreColor.NEUTRAL -> Amber
        ScoreColor.POOR    -> Red
    }

    val statusLabel = when {
        uiState.bleDeviceCount > 0 && uiState.todayScore >= 70 -> "Present"
        uiState.bleDeviceCount > 0 && uiState.todayScore < 70  -> "Phubbing"
        else                                                     -> "Alone"
    }
    val statusColor = when (statusLabel) {
        "Present"  -> Green
        "Phubbing" -> Amber
        else       -> TextSecondary
    }

    Scaffold(
        containerColor = BgPrimary,
        bottomBar = {
            BottomTabBar(current = TabDestination.Home) { dest ->
                when (dest) {
                    TabDestination.Live     -> navController.navigate(Routes.DETECTION)
                    TabDestination.Insights -> navController.navigate(Routes.INSIGHTS)
                    TabDestination.Group    -> navController.navigate(Routes.GROUP_DASH)
                    TabDestination.Settings -> navController.navigate(Routes.PERSONALIZATION)
                    else -> {}
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
        ) {
            // ── Header ────────────────────────────────────────────────────
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment     = Alignment.CenterVertically
            ) {
                Column {
                    Text(greeting, fontSize = 13.sp, color = Muted)
                    Row(
                        verticalAlignment     = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier              = Modifier.clickable { showNameDialog = true }
                    ) {
                        Text(
                            "$displayName 👋",
                            fontFamily = HeadingFamily,
                            fontSize   = 22.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color      = White
                        )
                        Text("✏️", fontSize = 14.sp)
                    }
                }
                Text(
                    "🛠",
                    fontSize = 20.sp,
                    modifier = Modifier.clickable { navController.navigate(Routes.USAGE_DEBUG) }
                )
            }

            // ── Status Card ───────────────────────────────────────────────
            Box(
                modifier = Modifier
                    .padding(horizontal = 20.dp, vertical = 8.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Surface1)
                    .border(1.dp, Border1, RoundedCornerShape(20.dp))
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier              = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment     = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                "CURRENT STATUS",
                                fontSize      = 11.sp,
                                color         = Muted,
                                fontWeight    = FontWeight.SemiBold,
                                letterSpacing = 1.sp
                            )
                            Spacer(Modifier.height(4.dp))
                            Row(
                                verticalAlignment     = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                PulsingDot(statusColor)
                                Text(
                                    statusLabel,
                                    fontFamily = HeadingFamily,
                                    fontSize   = 22.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color      = statusColor
                                )
                            }
                        }
                        PPChip(
                            if (uiState.bleDeviceCount > 0) "BLE ACTIVE" else "BLE IDLE",
                            if (uiState.bleDeviceCount > 0) ChipStyle.ACCENT else ChipStyle.GREEN
                        )
                    }
                    Spacer(Modifier.height(16.dp))
                    Row(
                        modifier              = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        PhoneStat("${uiState.todayScore}", "Score")
                        Box(Modifier.width(1.dp).height(32.dp).background(Border1))
                        PhoneStat("${uiState.phubCount}", "Phubs")
                        Box(Modifier.width(1.dp).height(32.dp).background(Border1))
                        PhoneStat("${uiState.bleDeviceCount}", "Nearby")
                        Box(Modifier.width(1.dp).height(32.dp).background(Border1))
                        PhoneStat("🔥 ${uiState.streakDays}", "Streak")
                    }
                }
            }

            // ── Score Ring ────────────────────────────────────────────────
            Column(
                modifier            = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                SectionTitle("Today's Presence Score")
                ScoreRing(score = uiState.todayScore, accentColor = scoreAccent)
                Spacer(Modifier.height(6.dp))
                Text(uiState.scoreLabel, fontSize = 12.sp, color = TextSecondary)
                if (uiState.phubCount > 0) {
                    Text(
                        "${uiState.phubCount} confirmed phub${if (uiState.phubCount == 1) "" else "s"} today",
                        fontSize = 11.sp,
                        color    = Muted,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }

            // ── Quick Stats ───────────────────────────────────────────────
            SectionTitle("Quick Stats", modifier = Modifier.padding(horizontal = 20.dp))
            Row(
                modifier              = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickStatCard("📱", "${uiState.phubCount}",       "Phubs Today",  Modifier.weight(1f))
                QuickStatCard("👥", "${uiState.socialMins}m",     "Social Mins",  Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            Row(
                modifier              = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickStatCard("📡", "${uiState.bleDeviceCount}",  "BLE Nearby",   Modifier.weight(1f))
                QuickStatCard("🔥", "${uiState.streakDays}",      "Day Streak",   Modifier.weight(1f))
            }

            // ── Detection CTA ─────────────────────────────────────────────
            Box(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF1A1060), Color(0xFF0C1526))))
                    .border(1.dp, Color(0xFF3D2FCC), RoundedCornerShape(14.dp))
                    .clickable { navController.navigate(Routes.DETECTION) }
                    .padding(16.dp)
            ) {
                Row(
                    modifier              = Modifier.fillMaxWidth(),
                    verticalAlignment     = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text("📡", fontSize = 28.sp)
                    Column(Modifier.weight(1f)) {
                        Text("Live Detection", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = White)
                        Text(
                            if (uiState.bleDeviceCount > 0)
                                "${uiState.bleDeviceCount} device${if (uiState.bleDeviceCount == 1) "" else "s"} in range"
                            else "BLE + Usage monitoring active",
                            fontSize = 11.sp,
                            color    = TextSecondary
                        )
                    }
                    Text("→", fontSize = 18.sp, color = Accent)
                }
            }

            Spacer(Modifier.height(8.dp))
        }
    }
}

// ── Change Name Dialog ────────────────────────────────────────────────────────

@Composable
private fun ChangeNameDialog(
    currentName : String,
    onDismiss   : () -> Unit,
    onConfirm   : (String) -> Unit
) {
    var newName    by remember { mutableStateOf("") }
    var isUpdating by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = { if (!isUpdating) onDismiss() }) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Surface1)
                .border(1.dp, Border1, RoundedCornerShape(20.dp))
                .padding(24.dp)
        ) {
            Text("Update Name", fontFamily = HeadingFamily, fontSize = 18.sp,
                fontWeight = FontWeight.Bold, color = White)
            Spacer(Modifier.height(6.dp))
            Text("Current: $currentName", fontSize = 11.sp, color = Muted)
            Spacer(Modifier.height(20.dp))
            PPTextField(
                value         = newName,
                onValueChange = { newName = it },
                label         = "New Name",
                placeholder   = currentName.ifBlank { "Enter your name" }
            )
            Spacer(Modifier.height(24.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick  = onDismiss,
                    enabled  = !isUpdating,
                    modifier = Modifier.weight(1f),
                    shape    = RoundedCornerShape(12.dp),
                    border   = androidx.compose.foundation.BorderStroke(1.dp, Border2),
                    colors   = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary)
                ) { Text("Cancel") }
                Button(
                    onClick  = {
                        if (newName.isNotBlank()) {
                            isUpdating = true
                            onConfirm(newName)
                        }
                    },
                    enabled  = !isUpdating && newName.isNotBlank(),
                    modifier = Modifier.weight(1f),
                    shape    = RoundedCornerShape(12.dp),
                    colors   = ButtonDefaults.buttonColors(containerColor = Accent)
                ) {
                    if (isUpdating)
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = White, strokeWidth = 2.dp)
                    else
                        Text("Save", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ── Private composables ───────────────────────────────────────────────────────

@Composable
private fun PhoneStat(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontFamily = MonoFamily, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = White)
        Text(label, fontSize = 9.sp, color = Muted, fontWeight = FontWeight.Medium, letterSpacing = 0.5.sp)
    }
}

@Composable
private fun ScoreRing(score: Int, accentColor: Color = Accent) {
    Box(modifier = Modifier.size(120.dp), contentAlignment = Alignment.Center) {
        Box(
            modifier = Modifier
                .size(120.dp)
                .clip(CircleShape)
                .background(
                    Brush.sweepGradient(listOf(accentColor, accentColor.copy(alpha = 0.3f), Surface2))
                )
        )
        Box(modifier = Modifier.size(100.dp).clip(CircleShape).background(BgSecondary))
        Text(
            score.toString(),
            fontFamily = HeadingFamily,
            fontSize   = 28.sp,
            fontWeight = FontWeight.ExtraBold,
            color      = accentColor
        )
    }
}

@Composable
private fun QuickStatCard(icon: String, value: String, label: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Surface1)
            .border(1.dp, Border1, RoundedCornerShape(14.dp))
            .padding(14.dp)
    ) {
        Text(icon, fontSize = 20.sp, modifier = Modifier.padding(bottom = 8.dp))
        Text(value, fontFamily = HeadingFamily, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = White)
        Text(label.uppercase(), fontSize = 10.sp, color = Muted, letterSpacing = 0.5.sp, modifier = Modifier.padding(top = 2.dp))
    }
}