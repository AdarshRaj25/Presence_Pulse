package com.blackbox.presencepulse.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.blackbox.presencepulse.ui.theme.*

// ─── TOP NAV BAR ────────────────────────────────────────────────────────────
@Composable
fun TopNavBar(
    title: String,
    onBack: (() -> Unit)? = null,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (onBack != null) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Surface1)
                    .border(1.dp, Border1, RoundedCornerShape(10.dp))
                    .clickable { onBack() },
                contentAlignment = Alignment.Center
            ) {
                Text("←", fontSize = 16.sp, color = TextSecondary)
            }
        }
        Text(
            title,
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.titleLarge
        )
        if (actionLabel != null && onAction != null) {
            Text(
                actionLabel,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = Accent,
                modifier = Modifier.clickable { onAction() }
            )
        }
    }
}

// ─── PRIMARY BUTTON ─────────────────────────────────────────────────────────
@Composable
fun PrimaryButton(label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Button(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .height(52.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Accent)
    ) {
        Text(label, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = White)
    }
}

// ─── SECONDARY BUTTON ────────────────────────────────────────────────────────
@Composable
fun SecondaryButton(label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .height(52.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = Accent),
        border = androidx.compose.foundation.BorderStroke(1.dp, Border2)
    ) {
        Text(label, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

// ─── INPUT FIELD ─────────────────────────────────────────────────────────────
@Composable
fun PPTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String = "",
    isPassword: Boolean = false,
    modifier: Modifier = Modifier
) {
    var passwordVisible by remember { mutableStateOf(false) }
    Column(modifier = modifier) {
        Text(label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextSecondary, modifier = Modifier.padding(bottom = 6.dp))
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            placeholder = { Text(placeholder, color = Muted) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Accent,
                unfocusedBorderColor = Border2,
                focusedTextColor = White,
                unfocusedTextColor = White,
                focusedContainerColor = Surface2,
                unfocusedContainerColor = Surface2,
                cursorColor = Accent
            ),
            visualTransformation = if (isPassword && !passwordVisible)
                androidx.compose.ui.text.input.PasswordVisualTransformation()
            else
                androidx.compose.ui.text.input.VisualTransformation.None,
            trailingIcon = if (isPassword) ({
                Text(
                    if (passwordVisible) "🙈" else "👁",
                    modifier = Modifier
                        .padding(end = 12.dp)
                        .clickable { passwordVisible = !passwordVisible },
                    fontSize = 16.sp
                )
            }) else null,
            singleLine = true
        )
    }
}

// ─── CHIP ────────────────────────────────────────────────────────────────────
enum class ChipStyle { ACCENT, GREEN, AMBER, RED, CYAN }

@Composable
fun PPChip(label: String, style: ChipStyle = ChipStyle.ACCENT) {
    val (bg, textColor, borderColor) = when (style) {
        ChipStyle.ACCENT -> Triple(Color(0x267C6FFF), AccentLight, Color(0x4D7C6FFF))
        ChipStyle.GREEN  -> Triple(Color(0x2000E5A0), Green, Color(0x4D00E5A0))
        ChipStyle.AMBER  -> Triple(Color(0x20FFB830), Amber, Color(0x4DFFB830))
        ChipStyle.RED    -> Triple(Color(0x20FF4D6D), Red, Color(0x4DFF4D6D))
        ChipStyle.CYAN   -> Triple(Color(0x2000E5FF), Cyan, Color(0x4D00E5FF))
    }
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(bg)
            .border(1.dp, borderColor, RoundedCornerShape(20.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(label.uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = textColor, letterSpacing = 0.5.sp)
    }
}

// ─── SECTION TITLE ───────────────────────────────────────────────────────────
@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(),
        modifier = modifier.padding(top = 24.dp, bottom = 12.dp),
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = HeadingFamily,
        color = Muted,
        letterSpacing = 1.5.sp
    )
}

// ─── CARD ─────────────────────────────────────────────────────────────────────
@Composable
fun PPCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Surface1)
            .border(1.dp, Border1, RoundedCornerShape(16.dp))
            .padding(16.dp),
        content = content
    )
}

// ─── TOGGLE SWITCH ────────────────────────────────────────────────────────────
@Composable
fun PPSwitch(checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Switch(
        checked = checked,
        onCheckedChange = onCheckedChange,
        colors = SwitchDefaults.colors(
            checkedThumbColor = White,
            checkedTrackColor = Accent,
            uncheckedThumbColor = White,
            uncheckedTrackColor = Surface2,
            uncheckedBorderColor = Border1
        )
    )
}

// ─── PULSING DOT ──────────────────────────────────────────────────────────────
@Composable
fun PulsingDot(color: Color = Green, size: Int = 6) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.4f, targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )
    Box(
        modifier = Modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(color.copy(alpha = alpha))
    )
}

// ─── BOTTOM TAB BAR ───────────────────────────────────────────────────────────
sealed class TabDestination(val icon: String, val label: String) {
    object Home      : TabDestination("🏠", "Home")
    object Live      : TabDestination("📡", "Live")
    object Insights  : TabDestination("📊", "Insights")
    object Group     : TabDestination("👥", "Group")
    object Settings  : TabDestination("⚙️", "Settings")
}

@Composable
fun BottomTabBar(
    current: TabDestination,
    onSelect: (TabDestination) -> Unit
) {
    val tabs = listOf(
        TabDestination.Home,
        TabDestination.Live,
        TabDestination.Insights,
        TabDestination.Group,
        TabDestination.Settings
    )
    Column {
        HorizontalDivider(color = Border1, thickness = 1.dp)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(BgPrimary.copy(alpha = 0.95f))
                .padding(top = 10.dp, bottom = 24.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            tabs.forEach { tab ->
                val isActive = tab == current
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onSelect(tab) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(tab.icon, fontSize = 20.sp)
                    Text(
                        tab.label.uppercase(),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isActive) Accent else Muted,
                        letterSpacing = 0.3.sp,
                        textAlign = TextAlign.Center
                    )
                    if (isActive) {
                        Box(
                            modifier = Modifier
                                .size(4.dp)
                                .clip(CircleShape)
                                .background(Accent)
                        )
                    } else {
                        Spacer(Modifier.height(4.dp))
                    }
                }
            }
        }
    }
}
