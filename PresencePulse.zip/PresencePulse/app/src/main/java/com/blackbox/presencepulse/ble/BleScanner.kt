package com.blackbox.presencepulse.ble

import android.Manifest
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Scans for BLE advertisements that carry the PresencePulse service UUID.
 *
 * Each PresencePulse device encodes the first 8 bytes of its Firebase UID
 * in the manufacturer data field (manufacturer ID = 0x4242).
 *
 * This scanner:
 *  1. Filters by PresencePulse UUID — ignores all non-app devices
 *  2. Decodes the UID prefix from manufacturer data
 *  3. Emits the set of UID prefixes seen — DetectionViewModel matches
 *     these against the friends list to show names
 *  4. Also emits a raw device count for the "total nearby" counter
 *
 * MAC randomisation is irrelevant — we identify devices by their UID
 * payload, not by MAC address.
 */
class BleScanner(private val context: Context) {

    private val bluetoothLeScanner by lazy {
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager)
            .adapter?.bluetoothLeScanner
    }

    // Set of UID prefixes (first 8 bytes as String) seen in this scan window
    private val _nearbyUidPrefixes = MutableStateFlow<Set<String>>(emptySet())
    val nearbyUidPrefixes: StateFlow<Set<String>> = _nearbyUidPrefixes.asStateFlow()

    // Total count of unique PresencePulse devices seen (with or without UID)
    private val _deviceCount = MutableStateFlow(0)
    val deviceCount: StateFlow<Int> = _deviceCount.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    // Internal mutable sets updated on every scan result
    private val seenUidPrefixes = mutableSetOf<String>()
    private val seenRssiBuckets = mutableSetOf<Int>()   // fallback for devices without UID

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            recordResult(result)
        }
        override fun onBatchScanResults(results: List<ScanResult>) {
            results.forEach { recordResult(it) }
        }
        override fun onScanFailed(errorCode: Int) {
            _isScanning.value = false
        }
    }

    private fun recordResult(result: ScanResult) {
        // Try to extract UID prefix from manufacturer data
        val mfData = result.scanRecord
            ?.getManufacturerSpecificData(BleConstants.MANUFACTURER_ID)

        if (mfData != null && mfData.isNotEmpty()) {
            // Known PresencePulse device with UID encoded
            val uidPrefix = mfData.toString(Charsets.UTF_8)
            seenUidPrefixes.add(uidPrefix)
            _nearbyUidPrefixes.value = seenUidPrefixes.toSet()
        } else {
            // PresencePulse UUID matched but no manufacturer data yet
            // (e.g. older build) — count via RSSI bucket
            seenRssiBuckets.add((result.rssi / 5) * 5)
        }

        // Total count = unique UID devices + RSSI-bucketed unknowns
        _deviceCount.value = seenUidPrefixes.size + seenRssiBuckets.size
    }

    fun hasPermissions(): Boolean = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) ==
                PackageManager.PERMISSION_GRANTED
    } else {
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED
    }

    fun startScan() {
        if (_isScanning.value || !hasPermissions()) return
        val scanner = bluetoothLeScanner ?: return

        seenUidPrefixes.clear()
        seenRssiBuckets.clear()
        _nearbyUidPrefixes.value = emptySet()
        _deviceCount.value       = 0

        val filter = ScanFilter.Builder()
            .setServiceUuid(BleConstants.PRESENCE_PULSE_PARCEL_UUID)
            .build()

        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()

        scanner.startScan(listOf(filter), settings, scanCallback)
        _isScanning.value = true
    }

    fun stopScan() {
        if (!_isScanning.value) return
        try { bluetoothLeScanner?.stopScan(scanCallback) } catch (_: Exception) {}
        _isScanning.value = false
    }
}