package com.blackbox.presencepulse.navigation

import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.blackbox.presencepulse.ui.screens.*

object Routes {
    const val SPLASH            = "splash"
    const val SIGNUP            = "signup"
    const val LOGIN             = "login"
    const val PERMISSION_CHECK  = "permission_check"
    const val ONBOARDING        = "onboarding"
    const val HOME              = "home"
    const val DETECTION         = "detection"
    const val NUDGE             = "nudge"
    const val INSIGHTS          = "insights"
    const val PERSONALIZATION   = "personalization"
    const val GROUP             = "group"
    const val GROUP_DASH        = "group_dash"
    const val USAGE_DEBUG       = "usage_debug"   // temp — remove before release
}

@Composable
fun PresencePulseNavGraph(navController: NavHostController) {

    val authViewModel: AuthViewModel = viewModel()
    var missingSteps by remember { mutableStateOf<List<OnboardingStep>>(emptyList()) }

    var prefillEmail by remember { mutableStateOf("") }

    NavHost(
        navController    = navController,
        startDestination = Routes.SPLASH
    ) {

        // ── Splash ────────────────────────────────────────────────────────
        composable(Routes.SPLASH) {
            SplashScreen(
                onSignUp = {
                    navController.navigate(Routes.SIGNUP) {
                        popUpTo(Routes.SPLASH) { inclusive = true }
                    }
                },
                onLogIn = {
                    navController.navigate(Routes.SIGNUP) {
                        popUpTo(Routes.SPLASH) { inclusive = true }
                    }
                    navController.navigate(Routes.LOGIN)
                },
                onAlreadyLoggedIn = {
                    navController.navigate(Routes.PERMISSION_CHECK) {
                        popUpTo(Routes.SPLASH) { inclusive = true }
                    }
                }
            )
        }

        // ── Sign Up ───────────────────────────────────────────────────────
        composable(Routes.SIGNUP) {
            SignUpScreen(
                authViewModel     = authViewModel,
                onSignUpSuccess   = {
                    navController.navigate(Routes.PERMISSION_CHECK) {
                        popUpTo(Routes.SIGNUP) { inclusive = true }
                    }
                },
                onNavigateToLogin = { emailToFill ->
                    prefillEmail = emailToFill
                    navController.navigate(Routes.LOGIN)
                }
            )
        }

        // ── Login ─────────────────────────────────────────────────────────
        composable(Routes.LOGIN) {
            LoginScreen(
                authViewModel      = authViewModel,
                prefillEmail       = prefillEmail,
                onLoginSuccess     = {
                    prefillEmail = ""
                    navController.navigate(Routes.PERMISSION_CHECK) {
                        popUpTo(Routes.SIGNUP) { inclusive = true }
                    }
                },
                onNavigateToSignUp = {
                    prefillEmail = ""
                    navController.popBackStack()
                }
            )
        }

        // ── Permission Check (invisible gate) ─────────────────────────────
        composable(Routes.PERMISSION_CHECK) {
            PermissionCheckScreen(
                onAllGranted = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.PERMISSION_CHECK) { inclusive = true }
                    }
                },
                onNeedPermissions = { missing ->
                    missingSteps = missing
                    navController.navigate(Routes.ONBOARDING) {
                        popUpTo(Routes.PERMISSION_CHECK) { inclusive = true }
                    }
                }
            )
        }

        // ── Onboarding ────────────────────────────────────────────────────
        composable(Routes.ONBOARDING) {
            OnboardingScreen(
                steps    = missingSteps,
                onFinish = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.ONBOARDING) { inclusive = true }
                    }
                }
            )
        }

        // ── Home ──────────────────────────────────────────────────────────
        composable(Routes.HOME) {
            HomeScreen(navController = navController)
        }

        // ── Detection (Live) ──────────────────────────────────────────────
        composable(Routes.DETECTION) {
            DetectionScreen(
                onBack        = { navController.popBackStack() },
                navController = navController
            )
        }

        // ── Nudge ─────────────────────────────────────────────────────────
        composable(Routes.NUDGE) {
            NudgeScreen(
                onBack        = { navController.popBackStack() },
                navController = navController
            )
        }

        // ── Insights ──────────────────────────────────────────────────────
        composable(Routes.INSIGHTS) {
            InsightsScreen(
                onBack        = { navController.popBackStack() },
                navController = navController
            )
        }

        // ── Personalization / Settings ────────────────────────────────────
        composable(Routes.PERSONALIZATION) {
            PersonalizationScreen(
                onBack        = { navController.popBackStack() },
                navController = navController
            )
        }

        // ── Group Management ──────────────────────────────────────────────
        composable(Routes.GROUP) {
            GroupScreen(
                onBack        = { navController.popBackStack() },
                navController = navController
            )
        }

        // ── Group Dashboard ───────────────────────────────────────────────
        composable(Routes.GROUP_DASH) {
            GroupDashScreen(
                onBack        = { navController.popBackStack() },
                navController = navController
            )
        }

        // ── Usage Debug (temp — remove before release) ────────────────────
        composable(Routes.USAGE_DEBUG) {
            UsageDebugScreen(
                onBack = { navController.popBackStack() }
            )
        }
    }
}