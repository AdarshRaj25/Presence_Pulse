package com.blackbox.presencepulse.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.blackbox.presencepulse.firebase.Friend
import com.blackbox.presencepulse.firebase.FriendRepository
import com.blackbox.presencepulse.firebase.FriendRequest
import com.blackbox.presencepulse.firebase.UserSearchResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class FriendUiState(
    val searchEmail      : String              = "",
    val searchResult     : UserSearchResult?   = null,
    val isSearching      : Boolean             = false,
    val searchError      : String?             = null,
    val requestSent      : Boolean             = false,
    val requestError     : String?             = null,
    val isSendingReq     : Boolean             = false,
    val incomingRequests : List<FriendRequest> = emptyList(),
    val friends          : List<Friend>        = emptyList()
)

class FriendViewModel(app: Application) : AndroidViewModel(app) {

    // Pass context so FriendRepository can access Room for offline cache
    private val repo = FriendRepository(app.applicationContext)

    private val _uiState = MutableStateFlow(FriendUiState())
    val uiState: StateFlow<FriendUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            repo.friendsFlow().collect { friends ->
                _uiState.value = _uiState.value.copy(friends = friends)
            }
        }
        viewModelScope.launch {
            repo.incomingRequestsFlow().collect { requests ->
                _uiState.value = _uiState.value.copy(incomingRequests = requests)
            }
        }
        viewModelScope.launch {
            repo.acceptedSentRequestsFlow().collect { accepted ->
                accepted.forEach { repo.finaliseFriendship(it) }
            }
        }
    }

    fun onSearchEmailChange(email: String) {
        _uiState.value = _uiState.value.copy(
            searchEmail  = email,
            searchResult = null,
            searchError  = null,
            requestSent  = false,
            requestError = null
        )
    }

    fun searchUser() {
        val email = _uiState.value.searchEmail.trim()
        if (email.isBlank()) return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isSearching = true, searchResult = null, searchError = null, requestSent = false, requestError = null)
            val result = repo.searchByEmail(email)
            _uiState.value = _uiState.value.copy(
                isSearching  = false,
                searchResult = result,
                searchError  = if (result == null) "No user found with that email." else null
            )
        }
    }

    fun sendRequest(toUid: String, toName: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isSendingReq = true, requestError = null)
            val result = repo.sendFriendRequest(toUid, toName)
            _uiState.value = _uiState.value.copy(
                isSendingReq = false,
                requestSent  = result.isSuccess,
                requestError = result.exceptionOrNull()?.message
            )
        }
    }

    fun acceptRequest(request: FriendRequest) {
        viewModelScope.launch { repo.acceptRequest(request) }
    }

    fun rejectRequest(requestId: String) {
        viewModelScope.launch { repo.rejectRequest(requestId) }
    }

    fun clearSearch() {
        _uiState.value = _uiState.value.copy(
            searchEmail  = "",
            searchResult = null,
            searchError  = null,
            requestSent  = false,
            requestError = null
        )
    }
}