package com.blackbox.presencepulse.ble

import android.Manifest
import android.bluetooth.BluetoothManager
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.ParcelUuid
import androidx.core.content.ContextCompat
import com.google.firebase.auth.FirebaseAuth
import java.util.UUID

object BleConstants {
    val PRESENCE_PULSE_UUID        = UUID.fromString("4fafc201-1fb5-459e-8fcc-c5c9c331914b")
    val PRESENCE_PULSE_PARCEL_UUID = ParcelUuid(PRESENCE_PULSE_UUID)
    // 0x4242 = "BB" for BlackBox — our manufacturer ID in the BLE payload
    const val MANUFACTURER_ID      = 0x4242
}

class BleAdvertiser(private val context: Context) {

    private val advertiser by lazy {
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager)
            .adapter?.bluetoothLeAdvertiser
    }

    private var isAdvertising = false

    private val callback = object : AdvertiseCallback() {
        override fun onStartSuccess(s: AdvertiseSettings) { isAdvertising = true }
        override fun onStartFailure(e: Int)               { isAdvertising = false }
    }

    fun hasPermission(): Boolean = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_ADVERTISE) ==
                PackageManager.PERMISSION_GRANTED
    } else {
        ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH) ==
                PackageManager.PERMISSION_GRANTED
    }

    fun startAdvertising() {
        if (isAdvertising || !hasPermission()) return
        val adv = advertiser ?: return
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return

        // Encode first 8 bytes of UID — fits BLE manufacturer data limit.
        // Scanner reads these bytes and matches against the friends list.
        val uidBytes = uid.toByteArray(Charsets.UTF_8).take(8).toByteArray()

        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM)
            .setConnectable(false)
            .build()

        val data = AdvertiseData.Builder()
            .addServiceUuid(BleConstants.PRESENCE_PULSE_PARCEL_UUID)
            .addManufacturerData(BleConstants.MANUFACTURER_ID, uidBytes)
            .setIncludeDeviceName(false)
            .build()

        adv.startAdvertising(settings, data, callback)
    }

    fun stopAdvertising() {
        if (!isAdvertising) return
        try { advertiser?.stopAdvertising(callback) } catch (_: Exception) {}
        isAdvertising = false
    }
}