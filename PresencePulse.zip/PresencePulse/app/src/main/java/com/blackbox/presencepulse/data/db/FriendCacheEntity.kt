package com.blackbox.presencepulse.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Local cache of the current user's accepted friends.
 * Written every time Firestore emits a friends update.
 * Read when the device is offline so DetectionViewModel
 * can still match BLE UID prefixes to names.
 */
@Entity(tableName = "friend_cache")
data class FriendCacheEntity(
    @PrimaryKey
    val uid       : String,
    val name      : String,
    val updatedAt : Long = System.currentTimeMillis()
)