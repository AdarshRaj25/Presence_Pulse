package com.blackbox.presencepulse.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.blackbox.presencepulse.ui.components.PrimaryButton
import com.blackbox.presencepulse.ui.components.SecondaryButton
import com.blackbox.presencepulse.ui.theme.*
import com.google.firebase.auth.FirebaseAuth

@Composable
fun SplashScreen(
    onSignUp: () -> Unit,
    onLogIn:  () -> Unit,
    onAlreadyLoggedIn: () -> Unit   // ← called immediately if session exists
) {
    // Check once on composition — no delay needed, this is instant
    val isLoggedIn = remember { FirebaseAuth.getInstance().currentUser != null }

    LaunchedEffect(isLoggedIn) {
        if (isLoggedIn) onAlreadyLoggedIn()
        // If not logged in, we just show the splash UI below normally
    }

    // Only render the splash UI when there is no existing session.
    // If there IS a session the LaunchedEffect fires immediately and we navigate away
    // before the user sees anything, so the UI below never flashes.
    if (!isLoggedIn) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(BgPrimary)
                .systemBarsPadding()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 40.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(88.dp)
                        .clip(RoundedCornerShape(26.dp))
                        .background(Brush.linearGradient(listOf(Accent, Color(0xFF5046E5)))),
                    contentAlignment = Alignment.Center
                ) {
                    Text("📡", fontSize = 40.sp)
                }

                Spacer(Modifier.height(28.dp))

                Text(
                    buildAnnotatedString {
                        append("Presence")
                        withStyle(SpanStyle(color = Accent)) { append("Pulse") }
                    },
                    fontFamily = HeadingFamily,
                    fontSize = 38.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = (-1.5).sp,
                    color = White,
                    textAlign = TextAlign.Center
                )

                Spacer(Modifier.height(10.dp))

                Text(
                    "Rediscover the people\nright in front of you.",
                    textAlign = TextAlign.Center,
                    fontSize = 14.sp,
                    color = TextSecondary,
                    lineHeight = 22.sp,
                    modifier = Modifier.padding(bottom = 36.dp)
                )

                PrimaryButton("Get Started →", onClick = onSignUp)
                Spacer(Modifier.height(10.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(Modifier.weight(1f).height(1.dp).background(Border1))
                    Text("or", fontSize = 11.sp, color = Muted)
                    Box(Modifier.weight(1f).height(1.dp).background(Border1))
                }

                Spacer(Modifier.height(2.dp))
                SecondaryButton("Log In", onClick = onLogIn)
            }
        }
    }
}
