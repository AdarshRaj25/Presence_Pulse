package com.blackbox.presencepulse.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface AppCacheDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(app: AppCacheEntity)

    @Query("SELECT * FROM app_cache WHERE packageName = :packageName LIMIT 1")
    suspend fun getByPackage(packageName: String): AppCacheEntity?
}