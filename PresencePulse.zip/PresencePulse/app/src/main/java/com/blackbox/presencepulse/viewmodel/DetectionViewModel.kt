package com.blackbox.presencepulse.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.blackbox.presencepulse.ble.BleBackgroundService
import com.blackbox.presencepulse.firebase.FriendRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class FriendInRange(
    val uid  : String,
    val name : String
)

data class DetectionUiState(
    val friendsInRange : List<FriendInRange> = emptyList(),
    val totalBleCount  : Int                 = 0,
    val isScanning     : Boolean             = false
)

class DetectionViewModel(app: Application) : AndroidViewModel(app) {

    // Context passed so FriendRepository can read from Room when offline
    private val friendRepo = FriendRepository(app.applicationContext)

    private val _uiState = MutableStateFlow(DetectionUiState())
    val uiState: StateFlow<DetectionUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            combine(
                friendRepo.friendsFlow(),
                BleBackgroundService.nearbyUidPrefixes,
                BleBackgroundService.deviceCount,
                BleBackgroundService.isScanning
            ) { friends, nearbyPrefixes, count, scanning ->

                // Match BLE UID prefixes against known friends
                val inRange = friends.filter { friend ->
                    val friendPrefix = friend.uid.take(8)
                    nearbyPrefixes.any { scanned ->
                        !scanned.startsWith("rssi_") &&
                                (scanned.startsWith(friendPrefix) ||
                                        friendPrefix.startsWith(scanned))
                    }
                }.map { FriendInRange(uid = it.uid, name = it.name) }

                // Count only real PresencePulse devices (not RSSI fallbacks)
                val realCount = nearbyPrefixes.count { !it.startsWith("rssi_") }
                    .let { if (it > 0) it else count }

                DetectionUiState(
                    friendsInRange = inRange,
                    totalBleCount  = realCount,
                    isScanning     = scanning
                )
            }.collect { _uiState.value = it }
        }
    }
}