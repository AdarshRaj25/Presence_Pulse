package com.blackbox.presencepulse.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.blackbox.presencepulse.permissions.PermissionUtils
import com.blackbox.presencepulse.service.UsagePollerService
import com.blackbox.presencepulse.ui.components.ChipStyle
import com.blackbox.presencepulse.ui.theme.BgPrimary

@Composable
fun PermissionCheckScreen(
    onAllGranted      : () -> Unit,
    onNeedPermissions : (List<OnboardingStep>) -> Unit
) {
    val context = LocalContext.current

    val bleStep = OnboardingStep(
        icon      = "📡",
        title     = "Bluetooth Scanning",
        desc      = "Detect nearby devices to know when loved ones are close — no GPS, no tracking.",
        permLabel = "ALLOW BLUETOOTH",
        chipStyle = ChipStyle.ACCENT
    )
    val usageStep = OnboardingStep(
        icon      = "📱",
        title     = "App Usage Access",
        desc      = "Monitor screen time to detect phubbing — only stats, never your content.",
        permLabel = "ALLOW USAGE ACCESS",
        chipStyle = ChipStyle.CYAN
    )
    val notifStep = OnboardingStep(
        icon      = "🔔",
        title     = "Notifications",
        desc      = "Receive gentle nudges and presence updates in real time.",
        permLabel = "ALLOW NOTIFICATIONS",
        chipStyle = ChipStyle.GREEN
    )
    val activityStep = OnboardingStep(
        icon      = "🏃",
        title     = "Activity Recognition",
        desc      = "Detects if you are walking or still so nudges only fire when relevant.",
        permLabel = "ALLOW ACTIVITY",
        chipStyle = ChipStyle.ACCENT
    )
    val overlayStep = OnboardingStep(
        icon      = "🔲",
        title     = "Display Over Apps",
        desc      = "Required to show phubbing nudges over your lock screen instantly.",
        permLabel = "ALLOW OVERLAY",
        chipStyle = ChipStyle.ACCENT
    )

    LaunchedEffect(Unit) {
        val missing = buildList {
            if (!PermissionUtils.isBleGranted(context))                  add(bleStep)
            if (!PermissionUtils.isUsageStatsGranted(context))           add(usageStep)
            if (!PermissionUtils.isNotificationGranted(context))         add(notifStep)
            if (!PermissionUtils.isActivityRecognitionGranted(context))  add(activityStep)
            if (!PermissionUtils.isOverlayGranted(context))              add(overlayStep)
        }

        if (missing.isEmpty()) {
            if (PermissionUtils.isUsageStatsGranted(context)) {
                UsagePollerService.start(context)
            }
            onAllGranted()
        } else {
            onNeedPermissions(missing)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BgPrimary)
    )
}