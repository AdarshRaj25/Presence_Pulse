package com.blackbox.presencepulse.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface UsageEventDao {

    // ── Writes ────────────────────────────────────────────────────────────────

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(events: List<UsageEventEntity>)

    @Query("DELETE FROM usage_events WHERE timeStamp < :cutoffMs")
    suspend fun deleteOlderThan(cutoffMs: Long)

    // ── Scorer queries ────────────────────────────────────────────────────────

    @Query("""
        SELECT COALESCE(SUM(durationMs), 0)
        FROM usage_events
        WHERE timeStamp >= :fromMs AND eventType = 2
    """)
    suspend fun totalUsageDurationSince(fromMs: Long): Long

    @Query("""
        SELECT packageName, category, SUM(durationMs) as durationMs
        FROM usage_events
        WHERE timeStamp >= :fromMs AND eventType = 2
        GROUP BY packageName
    """)
    suspend fun usageByPackageSince(fromMs: Long): List<PackageUsageSummary>

    @Query("""
        SELECT * FROM usage_events
        WHERE timeStamp >= :fromMs AND eventType IN (23, 24)
        ORDER BY timeStamp ASC
    """)
    suspend fun screenEventsSince(fromMs: Long): List<UsageEventEntity>

    // ── Insights queries ──────────────────────────────────────────────────────

    @Query("""
        SELECT (timeStamp / 86400000) * 86400000 AS dayBucket,
               SUM(durationMs) AS durationMs
        FROM usage_events
        WHERE timeStamp >= :fromMs AND eventType = 2
        GROUP BY dayBucket
        ORDER BY dayBucket ASC
    """)
    suspend fun dailyUsageSince(fromMs: Long): List<DailyUsageSummary>

    @Query("""
        SELECT packageName, appLabel, category, SUM(durationMs) as durationMs
        FROM usage_events
        WHERE timeStamp >= :fromMs AND eventType = 2
        GROUP BY packageName
        ORDER BY durationMs DESC
        LIMIT :limit
    """)
    suspend fun topAppsSince(fromMs: Long, limit: Int = 5): List<AppUsageSummary>

    @Query("""
        SELECT category, SUM(durationMs) as durationMs
        FROM usage_events
        WHERE timeStamp >= :fromMs AND eventType = 2
        GROUP BY category
        ORDER BY durationMs DESC
    """)
    suspend fun categoryBreakdownSince(fromMs: Long): List<CategoryUsageSummary>

    // ── Debug queries — remove before production release ──────────────────────

    @Query("SELECT COUNT(*) FROM usage_events")
    suspend fun debugTotalCount(): Int

    @Query("SELECT * FROM usage_events ORDER BY timeStamp DESC LIMIT :limit")
    suspend fun debugRecentEvents(limit: Int): List<UsageEventEntity>
}

data class PackageUsageSummary(
    val packageName : String,
    val category    : String,
    val durationMs  : Long
)

data class DailyUsageSummary(
    val dayBucket  : Long,
    val durationMs : Long
)

data class AppUsageSummary(
    val packageName : String,
    val appLabel    : String,
    val category    : String,
    val durationMs  : Long
)

data class CategoryUsageSummary(
    val category   : String,
    val durationMs : Long
)