package com.blackbox.presencepulse.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.blackbox.presencepulse.R

object NudgeNotificationHelper {

    const val CHANNEL_ID     = "pp_nudge_channel"
    const val EXTRA_EVENT_ID = "phub_event_id"

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Presence Nudges",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Phubbing confirmation prompts"
                enableVibration(true)
                setShowBadge(true)
            }
            context.getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    /**
     * Fires a heads-up notification that tapping opens NudgeOverlayActivity.
     * The overlay is the rich UI shown in the screenshot.
     * The notification itself is minimal — just a launch trigger.
     */
    fun fireNudge(
        context      : Context,
        eventId      : Long,
        appName      : String,
        bleCount     : Int,
        screenOnMs   : Long,
        confidence   : Float
    ) {
        createChannel(context)

        val overlayIntent = Intent(context, NudgeOverlayActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_EVENT_ID, eventId)
        }
        val pi = PendingIntent.getActivity(
            context,
            eventId.toInt(),
            overlayIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val screenOnText = PhubScorer.formatScreenOn(screenOnMs)
        val bleText      = "$bleCount BT device${if (bleCount == 1) "" else "s"} nearby"
        val appText      = if (appName.isNotBlank()) "$appName open · " else ""
        val confidencePct = (confidence * 100).toInt()

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Possible phubbing detected")
            .setContentText("$appText$bleText · $screenOnText")
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("$appText$bleText · $screenOnText\nML confidence: $confidencePct%\nTap to respond →")
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true)   // launches overlay immediately on lock screen
            .build()

        context.getSystemService(NotificationManager::class.java)
            .notify(notifId(eventId), notification)
    }

    fun cancelNudge(context: Context, eventId: Long) {
        context.getSystemService(NotificationManager::class.java)
            .cancel(notifId(eventId))
    }

    private fun notifId(eventId: Long) = (2000 + eventId % 1000).toInt()
}