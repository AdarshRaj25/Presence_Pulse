package com.blackbox.presencepulse.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.navigation.NavController
import com.blackbox.presencepulse.navigation.Routes
import com.blackbox.presencepulse.service.ContextSettingsManager
import com.blackbox.presencepulse.service.NudgeContext
import com.blackbox.presencepulse.ui.components.*
import com.blackbox.presencepulse.ui.theme.*
import java.util.UUID

data class ToggleSetting(val icon: String, val name: String, val desc: String, val enabled: Boolean)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PersonalizationScreen(onBack: () -> Unit, navController: NavController) {
    val context        = LocalContext.current
    var phubThreshold  by remember { mutableFloatStateOf(15f) }
    var nudgeCooldown  by remember { mutableFloatStateOf(5f) }

    var quietHoursEnabled by remember { mutableStateOf(true) }
    var quietStartHour    by remember { mutableIntStateOf(22) }
    var quietStartMinute  by remember { mutableIntStateOf(0) }
    var quietEndHour      by remember { mutableIntStateOf(7) }
    var quietEndMinute    by remember { mutableIntStateOf(0) }
    var showStartPicker   by remember { mutableStateOf(false) }
    var showEndPicker     by remember { mutableStateOf(false) }

    // Context management state
    var nudgeContexts     by remember {
        mutableStateOf(ContextSettingsManager.getContexts(context))
    }
    var showAddContext     by remember { mutableStateOf(false) }

    fun formatTime(h: Int, m: Int): String {
        val hour   = if (h % 12 == 0) 12 else h % 12
        val minute = m.toString().padStart(2, '0')
        val amPm   = if (h < 12) "AM" else "PM"
        return "$hour:$minute $amPm"
    }

    val toggles = remember {
        mutableStateListOf(
            ToggleSetting("📡", "BLE Scanning",    "Detect nearby devices",         true),
            ToggleSetting("📊", "Usage Stats",     "Monitor screen-on time",        true),
            ToggleSetting("🔔", "Nudge Alerts",    "Receive presence nudges",       true),
            ToggleSetting("👥", "Group Sharing",   "Share status with group",       false),
            ToggleSetting("🎵", "Sound Nudges",    "Play audio on phubbing detect", false),
            ToggleSetting("📳", "Haptic Feedback", "Vibrate with nudges",           true),
        )
    }

    if (showStartPicker) {
        TimePickerDialog(
            initialHour   = quietStartHour,
            initialMinute = quietStartMinute,
            onConfirm     = { h, m -> quietStartHour = h; quietStartMinute = m; showStartPicker = false },
            onDismiss     = { showStartPicker = false }
        )
    }
    if (showEndPicker) {
        TimePickerDialog(
            initialHour   = quietEndHour,
            initialMinute = quietEndMinute,
            onConfirm     = { h, m -> quietEndHour = h; quietEndMinute = m; showEndPicker = false },
            onDismiss     = { showEndPicker = false }
        )
    }
    if (showAddContext) {
        AddContextDialog(
            onDismiss = { showAddContext = false },
            onConfirm = { newCtx ->
                ContextSettingsManager.addContext(context, newCtx)
                nudgeContexts = ContextSettingsManager.getContexts(context)
                showAddContext = false
            }
        )
    }

    Scaffold(
        containerColor = BgPrimary,
        bottomBar = {
            BottomTabBar(current = TabDestination.Settings) { dest ->
                when (dest) {
                    TabDestination.Home     -> navController.navigate(Routes.HOME) { popUpTo(Routes.HOME) }
                    TabDestination.Live     -> navController.navigate(Routes.DETECTION)
                    TabDestination.Insights -> navController.navigate(Routes.INSIGHTS)
                    TabDestination.Group    -> navController.navigate(Routes.GROUP_DASH)
                    else -> {}
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
        ) {
            TopNavBar(title = "Settings", onBack = onBack)

            // ── Detection Thresholds ──────────────────────────────────────
            SectionTitle("Detection Thresholds", modifier = Modifier.padding(horizontal = 20.dp))
            Column(modifier = Modifier.padding(horizontal = 20.dp)) {
                Row(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Phubbing threshold", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextSecondary)
                    Text("${phubThreshold.toInt()} min", fontFamily = MonoFamily, fontSize = 12.sp, color = Accent)
                }
                Slider(value = phubThreshold, onValueChange = { phubThreshold = it },
                    valueRange = 5f..30f, steps = 4,
                    colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Surface2))
                Spacer(Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Nudge cooldown", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextSecondary)
                    Text("${nudgeCooldown.toInt()} min", fontFamily = MonoFamily, fontSize = 12.sp, color = Accent)
                }
                Slider(value = nudgeCooldown, onValueChange = { nudgeCooldown = it },
                    valueRange = 1f..15f, steps = 13,
                    colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Surface2))
            }

            // ── Nudge Contexts ────────────────────────────────────────────
            SectionTitle("Nudge Contexts", modifier = Modifier.padding(horizontal = 20.dp))
            Column(
                modifier = Modifier
                    .padding(horizontal = 20.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Surface1)
                    .border(1.dp, Border1, RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Text(
                    "Shown on nudge prompt · weight affects your score",
                    fontSize = 11.sp,
                    color    = Muted,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                nudgeContexts.forEachIndexed { i, ctx ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        verticalAlignment     = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(ctx.emoji, fontSize = 18.sp)
                        Column(Modifier.weight(1f)) {
                            Text(ctx.label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = White)
                            Text(
                                "Weight: ${ctx.weight}×",
                                fontSize = 11.sp,
                                color    = when {
                                    ctx.weight >= 1.3f -> Amber
                                    ctx.weight >= 1.0f -> Accent
                                    else               -> Muted
                                }
                            )
                        }
                        // Delete button
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Red.copy(alpha = 0.1f))
                                .border(1.dp, Red.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                .clickable {
                                    ContextSettingsManager.removeContext(context, ctx.id)
                                    nudgeContexts = ContextSettingsManager.getContexts(context)
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text("✕", fontSize = 11.sp, color = Red)
                        }
                    }
                    if (i < nudgeContexts.lastIndex) {
                        Box(Modifier.fillMaxWidth().height(1.dp).background(Border1))
                    }
                }

                Spacer(Modifier.height(12.dp))

                // Add context button
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Accent.copy(alpha = 0.1f))
                        .border(1.dp, Accent.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                        .clickable { showAddContext = true }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "+ Add Context",
                        fontSize   = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color      = Accent
                    )
                }
            }

            // ── Quiet Hours ───────────────────────────────────────────────
            SectionTitle("Quiet Hours", modifier = Modifier.padding(horizontal = 20.dp))
            Column(
                modifier = Modifier
                    .padding(horizontal = 20.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Surface1)
                    .border(1.dp, Border1, RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("No nudges during these hours", fontSize = 12.sp, color = TextSecondary)
                    PPSwitch(checked = quietHoursEnabled, onCheckedChange = { quietHoursEnabled = it })
                }
                if (quietHoursEnabled) {
                    Row(modifier = Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Column(
                            modifier = Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                                .background(Surface2).border(1.dp, Accent.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                                .clickable { showStartPicker = true }.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("FROM", fontSize = 10.sp, color = Muted, fontWeight = FontWeight.Medium, letterSpacing = 0.5.sp)
                            Spacer(Modifier.height(4.dp))
                            Text(formatTime(quietStartHour, quietStartMinute), fontFamily = MonoFamily, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = White)
                            Text("tap to change", fontSize = 9.sp, color = Accent, modifier = Modifier.padding(top = 2.dp))
                        }
                        Column(
                            modifier = Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                                .background(Surface2).border(1.dp, Accent.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                                .clickable { showEndPicker = true }.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("TO", fontSize = 10.sp, color = Muted, fontWeight = FontWeight.Medium, letterSpacing = 0.5.sp)
                            Spacer(Modifier.height(4.dp))
                            Text(formatTime(quietEndHour, quietEndMinute), fontFamily = MonoFamily, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = White)
                            Text("tap to change", fontSize = 9.sp, color = Accent, modifier = Modifier.padding(top = 2.dp))
                        }
                    }
                }
            }

            // ── Features ──────────────────────────────────────────────────
            SectionTitle("Features", modifier = Modifier.padding(horizontal = 20.dp))
            Column(
                modifier = Modifier
                    .padding(horizontal = 20.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Surface1)
                    .border(1.dp, Border1, RoundedCornerShape(14.dp))
            ) {
                toggles.forEachIndexed { i, setting ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 11.dp),
                        verticalAlignment     = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Box(
                            modifier = Modifier.size(38.dp).clip(RoundedCornerShape(10.dp)).background(Surface2),
                            contentAlignment = Alignment.Center
                        ) { Text(setting.icon, fontSize = 18.sp) }
                        Column(Modifier.weight(1f)) {
                            Text(setting.name, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = White)
                            Text(setting.desc, fontSize = 11.sp, color = Muted)
                        }
                        PPSwitch(checked = setting.enabled, onCheckedChange = { toggles[i] = setting.copy(enabled = it) })
                    }
                    if (i < toggles.lastIndex) Box(Modifier.fillMaxWidth().height(1.dp).background(Border1))
                }
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

// ── Add Context Dialog ────────────────────────────────────────────────────────

@Composable
private fun AddContextDialog(
    onDismiss : () -> Unit,
    onConfirm : (NudgeContext) -> Unit
) {
    var label  by remember { mutableStateOf("") }
    var emoji  by remember { mutableStateOf("") }
    var weight by remember { mutableFloatStateOf(1.0f) }

    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Surface1)
                .border(1.dp, Border1, RoundedCornerShape(20.dp))
                .padding(24.dp)
        ) {
            Text("Add Context", fontFamily = HeadingFamily, fontSize = 18.sp,
                fontWeight = FontWeight.Bold, color = White)
            Spacer(Modifier.height(16.dp))

            PPTextField(value = emoji, onValueChange = { emoji = it },
                label = "Emoji", placeholder = "🍽️")
            Spacer(Modifier.height(10.dp))
            PPTextField(value = label, onValueChange = { label = it },
                label = "Label", placeholder = "Family dinner")

            Spacer(Modifier.height(16.dp))

            // Weight slider
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Score weight", fontSize = 12.sp, color = TextSecondary)
                Text("${weight}×", fontFamily = MonoFamily, fontSize = 12.sp, color = when {
                    weight >= 1.3f -> Amber
                    weight >= 1.0f -> Accent
                    else           -> Muted
                })
            }
            Slider(
                value         = weight,
                onValueChange = { weight = (it * 10).toInt() / 10f },
                valueRange    = 0.5f..2.0f,
                steps         = 14,
                colors        = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Surface2)
            )
            Text(
                when {
                    weight >= 1.5f -> "High — family/romantic context"
                    weight >= 1.0f -> "Standard"
                    else           -> "Low — less strict context"
                },
                fontSize = 10.sp, color = Muted
            )

            Spacer(Modifier.height(20.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick  = onDismiss,
                    modifier = Modifier.weight(1f),
                    shape    = RoundedCornerShape(12.dp),
                    border   = androidx.compose.foundation.BorderStroke(1.dp, Border2),
                    colors   = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary)
                ) { Text("Cancel") }

                Button(
                    onClick  = {
                        if (label.isNotBlank()) {
                            onConfirm(NudgeContext(
                                id     = UUID.randomUUID().toString(),
                                emoji  = emoji.ifBlank { "📌" },
                                label  = label.trim(),
                                weight = weight
                            ))
                        }
                    },
                    enabled  = label.isNotBlank(),
                    modifier = Modifier.weight(1f),
                    shape    = RoundedCornerShape(12.dp),
                    colors   = ButtonDefaults.buttonColors(containerColor = Accent)
                ) { Text("Add", fontWeight = FontWeight.Bold) }
            }
        }
    }
}

// ── Time Picker Dialog ────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TimePickerDialog(
    initialHour   : Int,
    initialMinute : Int,
    onConfirm     : (Int, Int) -> Unit,
    onDismiss     : () -> Unit
) {
    val state = rememberTimePickerState(initialHour = initialHour, initialMinute = initialMinute, is24Hour = false)
    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(Surface1).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Select Time", fontFamily = HeadingFamily, fontSize = 18.sp,
                fontWeight = FontWeight.Bold, color = White, modifier = Modifier.padding(bottom = 20.dp))
            TimePicker(state = state, colors = TimePickerDefaults.colors(
                clockDialColor = Surface2, clockDialSelectedContentColor = White,
                clockDialUnselectedContentColor = TextSecondary, selectorColor = Accent,
                containerColor = Surface1,
                periodSelectorSelectedContainerColor = Accent, periodSelectorUnselectedContainerColor = Surface2,
                periodSelectorSelectedContentColor = White, periodSelectorUnselectedContentColor = TextSecondary,
                timeSelectorSelectedContainerColor = Accent, timeSelectorUnselectedContainerColor = Surface2,
                timeSelectorSelectedContentColor = White, timeSelectorUnselectedContentColor = TextSecondary,
            ))
            Row(modifier = Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Border2),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary)
                ) { Text("Cancel") }
                Button(onClick = { onConfirm(state.hour, state.minute) }, modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent)
                ) { Text("Set", fontWeight = FontWeight.Bold) }
            }
        }
    }
}