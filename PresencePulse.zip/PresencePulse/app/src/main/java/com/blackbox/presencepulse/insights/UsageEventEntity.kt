package com.blackbox.presencepulse.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * One row per UsageStats event.
 *
 * eventId  — hash of (packageName + timeStamp) used to deduplicate when the
 *             poller's 2-minute overlap window re-reads the same event.
 * eventType — UsageEvents.Event constants:
 *             1 = ACTIVITY_RESUMED  (screen came on / app foregrounded)
 *             2 = ACTIVITY_PAUSED   (app backgrounded)
 *             23 = SCREEN_INTERACTIVE (screen turned on)
 *             24 = SCREEN_NON_INTERACTIVE (screen turned off)
 * durationMs — only meaningful for PAUSED events; calculated as
 *              (pauseTime - last resumeTime) for the same package.
 *              0 for all other event types.
 * category  — resolved from PackageManager + cache, e.g. "Social", "Entertainment"
 */
@Entity(
    tableName = "usage_events",
    indices   = [Index(value = ["eventId"], unique = true)]
)
data class UsageEventEntity(
    @PrimaryKey(autoGenerate = true)
    val id          : Long   = 0,
    val eventId     : String,        // hash — dedup key
    val packageName : String,
    val appLabel    : String,        // human-readable app name
    val category    : String,        // resolved category
    val eventType   : Int,
    val timeStamp   : Long,          // epoch millis
    val durationMs  : Long  = 0L     // only set on PAUSED events
)