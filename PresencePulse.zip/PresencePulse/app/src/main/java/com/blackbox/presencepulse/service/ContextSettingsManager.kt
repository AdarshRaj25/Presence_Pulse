package com.blackbox.presencepulse.service

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Manages the list of social contexts shown on the nudge overlay.
 * Stored in SharedPreferences as JSON so the user can add/remove/reorder.
 *
 * Each context has:
 *   label  — display text ("Family dinner")
 *   emoji  — icon ("🍽️")
 *   weight — score multiplier (1.5 = more severe, 0.8 = less severe)
 */
data class NudgeContext(
    val id     : String,
    val emoji  : String,
    val label  : String,
    val weight : Float       // applied to event score: higher = more phubbing
)

object ContextSettingsManager {

    private const val PREFS_NAME = "nudge_contexts"
    private const val KEY        = "contexts_json"

    // Default contexts — matches the screenshot style
    val defaults = listOf(
        NudgeContext("family_dinner", "🍽️", "Family dinner", 1.5f),
        NudgeContext("work_meeting",  "💼", "Work meeting",  1.2f),
        NudgeContext("date",          "💑", "Date",          1.5f),
        NudgeContext("friends",       "👥", "Friends",       1.0f),
        NudgeContext("class",         "🎓", "Class",         0.8f)
    )

    fun getContexts(context: Context): List<NudgeContext> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val json  = prefs.getString(KEY, null) ?: return defaults

        return try {
            val arr  = JSONArray(json)
            (0 until arr.length()).map { i ->
                val obj = arr.getJSONObject(i)
                NudgeContext(
                    id     = obj.getString("id"),
                    emoji  = obj.getString("emoji"),
                    label  = obj.getString("label"),
                    weight = obj.getDouble("weight").toFloat()
                )
            }
        } catch (_: Exception) { defaults }
    }

    fun saveContexts(context: Context, contexts: List<NudgeContext>) {
        val arr = JSONArray()
        contexts.forEach { c ->
            arr.put(JSONObject().apply {
                put("id",     c.id)
                put("emoji",  c.emoji)
                put("label",  c.label)
                put("weight", c.weight.toDouble())
            })
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).apply()
    }

    fun addContext(context: Context, nudgeContext: NudgeContext) {
        val current = getContexts(context).toMutableList()
        current.add(nudgeContext)
        saveContexts(context, current)
    }

    fun removeContext(context: Context, id: String) {
        val current = getContexts(context).filter { it.id != id }
        saveContexts(context, current)
    }

    fun getWeightForId(context: Context, id: String): Float =
        getContexts(context).find { it.id == id }?.weight ?: 1.0f
}