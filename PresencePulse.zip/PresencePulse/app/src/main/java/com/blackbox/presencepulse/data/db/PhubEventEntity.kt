package com.blackbox.presencepulse.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One row per phubbing detection event.
 *
 * confirmation : "yes" | "no" | "timeout" | "pending"
 * socialContext: "known" | "unknown"
 * contextTag   : user-selected situation ("family_dinner", "date", etc.) — empty if not selected
 * contextWeight: multiplier from ContextSettingsManager at time of confirmation
 * mlConfidence : 0.0–1.0 confidence from PhubScorer heuristic
 */
@Entity(tableName = "phub_events")
data class PhubEventEntity(
    @PrimaryKey(autoGenerate = true)
    val id            : Long   = 0,
    val timestampMs   : Long,
    val confirmation  : String = "pending",
    val socialContext : String,               // known / unknown
    val knownCount    : Int    = 0,
    val unknownCount  : Int    = 0,
    val screenOnMs    : Long   = 0L,
    val topPackage    : String = "",
    val topCategory   : String = "Unknown",
    val mlActivity    : String = "STILL",
    val mlConfidence  : Float  = 0f,          // heuristic confidence 0–1
    val contextTag    : String = "",          // selected context id
    val contextWeight : Float  = 1.0f,        // weight applied to score
    val score         : Float  = 0f
)