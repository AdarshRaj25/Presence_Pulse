package com.blackbox.presencepulse.service

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.blackbox.presencepulse.data.db.AppDatabase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class NudgeOverlayUiState(
    val isLoading         : Boolean = true,
    val isFinished        : Boolean = false,
    val eventId           : Long    = -1L,
    val appName           : String  = "",
    val appCategory       : String  = "",
    val knownCount        : Int     = 0,
    val unknownCount      : Int     = 0,
    val screenOnMs        : Long    = 0L,
    val mlConfidence      : Float   = 0.7f,
    val selectedContextId : String? = null
)

class NudgeOverlayViewModel(app: Application) : AndroidViewModel(app) {

    private val dao = AppDatabase.getInstance(app).phubEventDao()

    private val _uiState = MutableStateFlow(NudgeOverlayUiState())
    val uiState: StateFlow<NudgeOverlayUiState> = _uiState.asStateFlow()

    private val _contexts = MutableStateFlow<List<NudgeContext>>(emptyList())
    val contexts: StateFlow<List<NudgeContext>> = _contexts.asStateFlow()

    fun loadEvent(eventId: Long, context: Context) {
        viewModelScope.launch {
            _contexts.value = ContextSettingsManager.getContexts(context)

            if (eventId < 0) {
                _uiState.value = _uiState.value.copy(isLoading = false)
                return@launch
            }

            val event = dao.getById(eventId)
            if (event == null) {
                _uiState.value = _uiState.value.copy(isLoading = false)
                return@launch
            }

            // Resolve human-readable app name
            val appName = try {
                if (event.topPackage.isBlank()) ""
                else {
                    val pm   = context.packageManager
                    val info = pm.getApplicationInfo(event.topPackage, 0)
                    pm.getApplicationLabel(info).toString()
                }
            } catch (_: Exception) { event.topPackage }

            _uiState.value = NudgeOverlayUiState(
                isLoading    = false,
                eventId      = eventId,
                appName      = appName,
                appCategory  = event.topCategory,
                knownCount   = event.knownCount,
                unknownCount = event.unknownCount,
                screenOnMs   = event.screenOnMs,
                mlConfidence = event.mlConfidence
            )
        }
    }

    fun selectContext(contextId: String) {
        val current = _uiState.value.selectedContextId
        // Toggle — tap again to deselect
        _uiState.value = _uiState.value.copy(
            selectedContextId = if (current == contextId) null else contextId
        )
    }

    fun confirm(answer: String) {
        val state = _uiState.value
        if (state.eventId < 0) {
            _uiState.value = state.copy(isFinished = true)
            return
        }

        viewModelScope.launch {
            val event = dao.getById(state.eventId) ?: run {
                _uiState.value = state.copy(isFinished = true)
                return@launch
            }

            // Get context weight if a context was selected
            val contextWeight = state.selectedContextId?.let { id ->
                _contexts.value.find { it.id == id }?.weight
            } ?: 1.0f

            val updated = event.copy(
                confirmation  = answer,
                contextTag    = state.selectedContextId ?: "",
                contextWeight = contextWeight,
                score         = if (answer == "yes" || answer == "timeout")
                    PhubScorer.computeEventScore(
                        event.copy(
                            confirmation  = answer,
                            contextWeight = contextWeight
                        )
                    )
                else 0f
            )
            dao.update(updated)
            NudgeNotificationHelper.cancelNudge(getApplication(), state.eventId)

            _uiState.value = state.copy(isFinished = true)
        }
    }
}