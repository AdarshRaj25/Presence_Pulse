package com.blackbox.presencepulse.service

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.blackbox.presencepulse.ui.theme.*

/**
 * Full-screen Compose activity used as an overlay.
 * Appears over the lock screen and other apps via showWhenLocked +
 * FLAG_SHOW_WHEN_LOCKED flags.
 *
 * Matches the screenshot:
 *   - App icon + "Phubber / Behaviour detection" header
 *   - "Possible phubbing detected" title
 *   - Context line: "Instagram open · 2 BT devices nearby · 3 min 12 sec screen-on"
 *   - ML confidence bar with percentage
 *   - "What were you doing? (optional)" context selector chips
 *   - "Not this time" / "Yes, I was" action buttons
 */
class NudgeOverlayActivity : ComponentActivity() {

    private val viewModel: NudgeOverlayViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Show over lock screen
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Load the event from intent
        val eventId = intent.getLongExtra(NudgeNotificationHelper.EXTRA_EVENT_ID, -1L)
        viewModel.loadEvent(eventId, applicationContext)

        setContent {
            PresencePulseTheme {
                NudgeOverlayScreen(
                    viewModel  = viewModel,
                    onFinished = { finish() }
                )
            }
        }
    }
}

@Composable
private fun NudgeOverlayScreen(
    viewModel  : NudgeOverlayViewModel,
    onFinished : () -> Unit
) {
    val state    by viewModel.uiState.collectAsStateWithLifecycle()
    val contexts by viewModel.contexts.collectAsStateWithLifecycle()

    // Auto-finish when confirmed
    LaunchedEffect(state.isFinished) {
        if (state.isFinished) onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.85f)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .padding(20.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF12203A), Color(0xFF0C1526))
                    )
                )
                .border(1.dp, Color(0xFF1E3A5F), RoundedCornerShape(24.dp))
                .padding(20.dp)
        ) {
            // ── Header ────────────────────────────────────────────────────
            Row(
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier              = Modifier.padding(bottom = 16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Accent.copy(alpha = 0.15f))
                        .border(1.dp, Accent.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) { Text("📵", fontSize = 20.sp) }

                Column(Modifier.weight(1f)) {
                    Text(
                        "Phubber",
                        fontSize   = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color      = White
                    )
                    Text(
                        "Behaviour detection",
                        fontSize = 11.sp,
                        color    = TextSecondary
                    )
                }
                Text("just now", fontSize = 10.sp, color = Muted)
            }

            // ── Title ─────────────────────────────────────────────────────
            Text(
                "Possible phubbing detected",
                fontSize   = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color      = White,
                modifier   = Modifier.padding(bottom = 6.dp)
            )

            // ── Context line ──────────────────────────────────────────────
            Text(
                buildContextLine(state),
                fontSize   = 12.sp,
                color      = TextSecondary,
                lineHeight = 18.sp,
                modifier   = Modifier.padding(bottom = 16.dp)
            )

            // ── ML Confidence bar ─────────────────────────────────────────
            Row(
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier              = Modifier.padding(bottom = 20.dp)
            ) {
                Text(
                    "ML confidence",
                    fontSize = 11.sp,
                    color    = TextSecondary,
                    modifier = Modifier.width(90.dp)
                )
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(Surface2)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(state.mlConfidence)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(3.dp))
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Color(0xFF4CAF50), Color(0xFF8BC34A))
                                )
                            )
                    )
                }
                Text(
                    "${(state.mlConfidence * 100).toInt()}%",
                    fontSize   = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color      = Color(0xFF8BC34A)
                )
            }

            // ── Context selector ──────────────────────────────────────────
            Text(
                "What were you doing? (optional)",
                fontSize = 11.sp,
                color    = Muted,
                modifier = Modifier.padding(bottom = 10.dp)
            )

            // First row of contexts
            val rows = contexts.chunked(2)
            rows.forEach { row ->
                Row(
                    modifier              = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    row.forEach { ctx ->
                        val selected = state.selectedContextId == ctx.id
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (selected) Accent.copy(alpha = 0.2f)
                                    else Surface1
                                )
                                .border(
                                    1.dp,
                                    if (selected) Accent else Border1,
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { viewModel.selectContext(ctx.id) }
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "${ctx.emoji}  ${ctx.label}",
                                fontSize   = 12.sp,
                                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                                color      = if (selected) White else TextSecondary
                            )
                        }
                    }
                    // Fill empty slot if odd number
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }

            Spacer(Modifier.height(8.dp))

            // ── Action buttons ────────────────────────────────────────────
            Row(
                modifier              = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Not this time
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Surface1)
                        .border(1.dp, Border1, RoundedCornerShape(14.dp))
                        .clickable { viewModel.confirm("no") }
                        .padding(vertical = 14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "✕  Not this time",
                        fontSize   = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color      = TextSecondary
                    )
                }

                // Yes, I was
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            Brush.linearGradient(listOf(Accent, Color(0xFF5046E5)))
                        )
                        .clickable { viewModel.confirm("yes") }
                        .padding(vertical = 14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "✓  Yes, I was",
                        fontSize   = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color      = White
                    )
                }
            }
        }
    }
}

private fun buildContextLine(state: NudgeOverlayUiState): String {
    val parts = mutableListOf<String>()
    if (state.appName.isNotBlank()) parts += "${state.appName} open"
    val bleCount = state.knownCount + state.unknownCount
    if (bleCount > 0) parts += "$bleCount BT device${if (bleCount == 1) "" else "s"} nearby"
    parts += PhubScorer.formatScreenOn(state.screenOnMs)
    return parts.joinToString(" · ")
}