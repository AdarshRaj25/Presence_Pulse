package com.blackbox.presencepulse.permissions

import android.app.AppOpsManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import android.provider.Settings
import androidx.core.content.ContextCompat

object PermissionUtils {

    // ── Bluetooth ─────────────────────────────────────────────────────────────
    fun isBleGranted(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            hasPermission(context, android.Manifest.permission.BLUETOOTH_SCAN)      &&
                    hasPermission(context, android.Manifest.permission.BLUETOOTH_CONNECT)   &&
                    hasPermission(context, android.Manifest.permission.BLUETOOTH_ADVERTISE)
        } else {
            hasPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    // ── Usage Stats ───────────────────────────────────────────────────────────
    fun isUsageStatsGranted(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode   = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    // ── Notifications ─────────────────────────────────────────────────────────
    fun isNotificationGranted(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            hasPermission(context, android.Manifest.permission.POST_NOTIFICATIONS)
        } else true
    }

    // ── Activity Recognition (ML Kit) ─────────────────────────────────────────
    fun isActivityRecognitionGranted(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            hasPermission(context, android.Manifest.permission.ACTIVITY_RECOGNITION)
        } else true
    }

    // ── Draw Over Other Apps (overlay) ────────────────────────────────────────
    fun isOverlayGranted(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else true
    }

    // ── All ───────────────────────────────────────────────────────────────────
    fun allGranted(context: Context): Boolean =
        isBleGranted(context)              &&
                isUsageStatsGranted(context)       &&
                isNotificationGranted(context)     &&
                isActivityRecognitionGranted(context) &&
                isOverlayGranted(context)

    private fun hasPermission(context: Context, permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
}