package com.blackbox.presencepulse.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.blackbox.presencepulse.navigation.Routes
import com.blackbox.presencepulse.ui.components.*
import com.blackbox.presencepulse.ui.theme.*
import com.blackbox.presencepulse.viewmodel.InsightsViewModel
import com.blackbox.presencepulse.viewmodel.ScoreColor

@Composable
fun InsightsScreen(
    onBack        : () -> Unit,
    navController : NavController,
    viewModel     : InsightsViewModel = viewModel()
) {
    val uiState        by viewModel.uiState.collectAsStateWithLifecycle()
    // Reload every time screen comes into view
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) viewModel.loadAll()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    var selectedPeriod by remember { mutableIntStateOf(0) }
    val periods         = listOf("Day", "Week", "Month")

    Scaffold(
        containerColor = BgPrimary,
        bottomBar = {
            BottomTabBar(current = TabDestination.Insights) { dest ->
                when (dest) {
                    TabDestination.Home     -> navController.navigate(Routes.HOME) { popUpTo(Routes.HOME) }
                    TabDestination.Live     -> navController.navigate(Routes.DETECTION)
                    TabDestination.Group    -> navController.navigate(Routes.GROUP_DASH)
                    TabDestination.Settings -> navController.navigate(Routes.PERSONALIZATION)
                    else -> {}
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
        ) {
            TopNavBar(title = "Insights", onBack = onBack)

            if (uiState.isLoading) {
                Box(
                    modifier         = Modifier.fillMaxWidth().padding(vertical = 60.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = Accent, strokeWidth = 2.dp)
                }
                return@Column
            }

            // ── Period Toggle ─────────────────────────────────────────────
            Row(
                modifier = Modifier
                    .padding(horizontal = 20.dp, vertical = 4.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Surface1)
                    .border(1.dp, Border1, RoundedCornerShape(10.dp))
                    .padding(3.dp)
            ) {
                periods.forEachIndexed { i, label ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(7.dp))
                            .background(if (i == selectedPeriod) Accent else Color.Transparent)
                            .clickable { selectedPeriod = i; viewModel.loadAll() }
                            .padding(vertical = 7.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            label,
                            fontSize   = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color      = if (i == selectedPeriod) White else Muted
                        )
                    }
                }
            }

            // ── Score Summary Card ────────────────────────────────────────
            val scoreAccent = when (uiState.scoreColor) {
                ScoreColor.GREAT   -> Green
                ScoreColor.GOOD    -> Accent
                ScoreColor.NEUTRAL -> Amber
                ScoreColor.POOR    -> Red
            }

            Column(
                modifier = Modifier
                    .padding(horizontal = 20.dp, vertical = 8.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Surface1)
                    .border(1.dp, Border1, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Row(
                    modifier              = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment     = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            "Presence Score",
                            fontFamily = HeadingFamily,
                            fontSize   = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color      = White
                        )
                        Text(uiState.scoreLabel, fontSize = 11.sp, color = Muted)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            "${uiState.todayScore}",
                            fontFamily = HeadingFamily,
                            fontSize   = 36.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color      = scoreAccent
                        )
                        if (uiState.phubCount > 0) {
                            Text(
                                "${uiState.phubCount} phub${if (uiState.phubCount == 1) "" else "s"}",
                                fontSize = 10.sp,
                                color    = Muted
                            )
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                // Score progress bar
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(Surface2)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(uiState.todayScore / 100f)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(3.dp))
                            .background(
                                Brush.horizontalGradient(
                                    listOf(scoreAccent.copy(alpha = 0.7f), scoreAccent)
                                )
                            )
                    )
                }
                Spacer(Modifier.height(14.dp))
                // Mini stats row
                Row(
                    modifier              = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    MiniStat("📱", "${uiState.pickupCount}", "Pickups")
                    Box(Modifier.width(1.dp).height(32.dp).background(Border1))
                    MiniStat("👥", "${uiState.socialMins}m", "Social")
                    Box(Modifier.width(1.dp).height(32.dp).background(Border1))
                    MiniStat("🔥", "${uiState.streakDays}", "Streak")
                    Box(Modifier.width(1.dp).height(32.dp).background(Border1))
                    MiniStat("📡", "${uiState.bleDeviceCount}", "Nearby")
                }
            }

            // ── Weekly Bar Chart ──────────────────────────────────────────
            Column(
                modifier = Modifier
                    .padding(horizontal = 20.dp, vertical = 8.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Surface1)
                    .border(1.dp, Border1, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Text(
                    "Weekly Presence",
                    fontFamily = HeadingFamily,
                    fontSize   = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color      = White
                )
                Text(
                    "Presence score per day this week",
                    fontSize = 11.sp,
                    color    = Muted,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
                if (uiState.weeklyScores.isEmpty()) {
                    Text(
                        "No data yet — scores appear after first confirmed nudge",
                        fontSize = 11.sp,
                        color    = Muted
                    )
                } else {
                    Row(
                        modifier              = Modifier.fillMaxWidth().height(80.dp),
                        verticalAlignment     = Alignment.Bottom,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val maxScore = uiState.weeklyScores.maxOfOrNull { it.second } ?: 100f
                        uiState.weeklyScores.forEach { (day, score) ->
                            Column(
                                modifier              = Modifier.weight(1f),
                                horizontalAlignment   = Alignment.CenterHorizontally,
                                verticalArrangement   = Arrangement.Bottom
                            ) {
                                Box(
                                    modifier         = Modifier.weight(1f).fillMaxWidth(),
                                    contentAlignment = Alignment.BottomCenter
                                ) {
                                    val heightFraction = (score / maxScore.coerceAtLeast(1f)).coerceIn(0.05f, 1f)
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .fillMaxHeight(heightFraction)
                                            .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                                            .background(
                                                if (score == maxScore)
                                                    Brush.verticalGradient(listOf(AccentLight, Accent))
                                                else
                                                    Brush.verticalGradient(listOf(Accent.copy(alpha = 0.7f), Accent.copy(alpha = 0.4f)))
                                            )
                                    )
                                }
                                Text(day, fontSize = 9.sp, color = Muted, modifier = Modifier.padding(top = 4.dp))
                            }
                        }
                    }
                }
            }

            // ── Key Insights ──────────────────────────────────────────────
            SectionTitle("Key Insights", modifier = Modifier.padding(horizontal = 20.dp))
            Column(
                modifier            = Modifier.padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (uiState.keyInsights.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Surface1)
                            .border(1.dp, Border1, RoundedCornerShape(14.dp))
                            .padding(16.dp)
                    ) {
                        Text(
                            "Insights appear after your first nudge is confirmed.",
                            fontSize = 12.sp,
                            color    = TextSecondary
                        )
                    }
                } else {
                    uiState.keyInsights.forEach { (icon, title, desc) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(Surface1)
                                .border(1.dp, Border1, RoundedCornerShape(14.dp))
                                .padding(14.dp),
                            verticalAlignment     = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Box(
                                modifier         = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Surface2),
                                contentAlignment = Alignment.Center
                            ) { Text(icon, fontSize = 20.sp) }
                            Column {
                                Text(title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = White)
                                Text(desc,  fontSize = 11.sp, color = Muted, lineHeight = 16.sp)
                            }
                        }
                    }
                }
            }

            // ── Presence Heatmap ──────────────────────────────────────────
            Column(
                modifier = Modifier
                    .padding(horizontal = 20.dp, vertical = 16.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Surface1)
                    .border(1.dp, Border1, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Text(
                    "Presence Heatmap",
                    fontFamily = HeadingFamily,
                    fontSize   = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color      = White
                )
                Text(
                    "Last 4 weeks · green = present",
                    fontSize = 11.sp,
                    color    = Muted,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
                if (uiState.heatmapData.isEmpty()) {
                    Text("No data yet", fontSize = 11.sp, color = Muted)
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        uiState.heatmapData.chunked(7).forEach { row ->
                            Row(
                                modifier              = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                row.forEach { intensity ->
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .aspectRatio(1f)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(
                                                when {
                                                    intensity >= 0.8f -> Green.copy(alpha = 0.8f)
                                                    intensity >= 0.6f -> Accent.copy(alpha = 0.7f)
                                                    intensity >= 0.4f -> Accent.copy(alpha = 0.4f)
                                                    intensity >= 0.2f -> Accent.copy(alpha = 0.2f)
                                                    else              -> Surface2
                                                }
                                            )
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun MiniStat(icon: String, value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(icon, fontSize = 14.sp)
        Text(
            value,
            fontFamily = MonoFamily,
            fontSize   = 14.sp,
            fontWeight = FontWeight.Bold,
            color      = White
        )
        Text(label, fontSize = 9.sp, color = Muted, letterSpacing = 0.3.sp)
    }
}