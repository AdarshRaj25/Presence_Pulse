package com.blackbox.presencepulse.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.blackbox.presencepulse.data.db.AppDatabase
import com.blackbox.presencepulse.data.db.UsageEventEntity
import com.blackbox.presencepulse.service.UsagePollerService
import com.blackbox.presencepulse.ui.components.PrimaryButton
import com.blackbox.presencepulse.ui.components.SecondaryButton
import com.blackbox.presencepulse.ui.theme.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun UsageDebugScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val db      = remember { AppDatabase.getInstance(context) }

    var totalEvents  by remember { mutableIntStateOf(0) }
    var recentEvents by remember { mutableStateOf<List<UsageEventEntity>>(emptyList()) }
    var isPolling    by remember { mutableStateOf(false) }
    var lastRefresh  by remember { mutableLongStateOf(0L) }

    // Auto-refresh every 5 seconds so we can watch rows appear in real time
    LaunchedEffect(Unit) {
        while (true) {
            recentEvents = db.usageEventDao().debugRecentEvents(20)
            totalEvents  = db.usageEventDao().debugTotalCount()
            lastRefresh  = System.currentTimeMillis()
            delay(5_000)
        }
    }

    val sdf = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }

    Scaffold(containerColor = BgPrimary) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Spacer(Modifier.height(20.dp))
                Text(
                    "Usage Poller Debug",
                    fontFamily = HeadingFamily,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = White
                )
                Text(
                    "Last refresh: ${sdf.format(Date(lastRefresh))} · auto-refreshes every 5s",
                    fontSize = 11.sp,
                    color = Muted,
                    modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                )
            }

            // ── Summary stats ─────────────────────────────────────────────────
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatBox("Total rows", totalEvents.toString(), Modifier.weight(1f))
                    StatBox("Shown", recentEvents.size.toString(), Modifier.weight(1f))
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    if (totalEvents > 0)
                        "✅ Poller is writing to Room"
                    else
                        "⏳ Waiting for first poll (up to 60s after service start)",
                    fontSize = 12.sp,
                    color = if (totalEvents > 0) Green else Amber,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }

            // ── Service controls ──────────────────────────────────────────────
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PrimaryButton(
                        label   = "Start Service",
                        onClick = {
                            UsagePollerService.start(context)
                            isPolling = true
                        },
                        modifier = Modifier.weight(1f)
                    )
                    SecondaryButton(
                        label   = "Stop Service",
                        onClick = {
                            UsagePollerService.stop(context)
                            isPolling = false
                        },
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(Modifier.height(8.dp))
            }

            // ── Event type legend ─────────────────────────────────────────────
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Surface1)
                        .border(1.dp, Border1, RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Event Types", fontSize = 11.sp, color = Muted, fontWeight = FontWeight.SemiBold)
                        Text("1 = RESUMED  2 = PAUSED  23 = SCREEN ON  24 = SCREEN OFF",
                            fontSize = 11.sp, color = TextSecondary, fontFamily = MonoFamily)
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text("Last 20 events (newest first)", fontSize = 12.sp,
                    color = Muted, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
            }

            // ── Event rows ────────────────────────────────────────────────────
            if (recentEvents.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Surface1)
                            .border(1.dp, Border1, RoundedCornerShape(12.dp))
                            .padding(20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("No events yet — start the service and wait up to 60s",
                            fontSize = 12.sp, color = Muted)
                    }
                }
            } else {
                items(recentEvents) { event ->
                    EventRow(event, sdf)
                }
            }

            item { Spacer(Modifier.height(12.dp)) }
            item {
                SecondaryButton(label = "← Back", onClick = onBack,
                    modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun StatBox(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Surface1)
            .border(1.dp, Border1, RoundedCornerShape(12.dp))
            .padding(14.dp)
    ) {
        Text(value, fontFamily = HeadingFamily, fontSize = 28.sp,
            fontWeight = FontWeight.ExtraBold, color = Accent)
        Text(label, fontSize = 11.sp, color = Muted)
    }
}

@Composable
private fun EventRow(event: UsageEventEntity, sdf: SimpleDateFormat) {
    val typeColor = when (event.eventType) {
        1    -> Green         // RESUMED
        2    -> Amber         // PAUSED
        23   -> Accent        // SCREEN ON
        24   -> TextSecondary // SCREEN OFF
        else -> Muted
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Surface1)
            .border(1.dp, Border1, RoundedCornerShape(10.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(event.appLabel, fontSize = 12.sp, color = White,
                fontWeight = FontWeight.SemiBold)
            Text(event.category, fontSize = 10.sp, color = Muted)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text("type ${event.eventType}", fontSize = 11.sp,
                color = typeColor, fontFamily = MonoFamily)
            Text(sdf.format(Date(event.timeStamp)), fontSize = 10.sp,
                color = Muted, fontFamily = MonoFamily)
            if (event.durationMs > 0) {
                Text("${event.durationMs / 1000}s", fontSize = 10.sp,
                    color = TextSecondary, fontFamily = MonoFamily)
            }
        }
    }
}