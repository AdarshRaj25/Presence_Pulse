package com.blackbox.presencepulse.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// ─── COLOR PALETTE ──────────────────────────────────────────────────────────
val BgPrimary     = Color(0xFF070D1A)
val BgSecondary   = Color(0xFF0C1526)
val Surface1      = Color(0xFF111F36)
val Surface2      = Color(0xFF172847)
val Border1       = Color(0xFF1E3456)
val Border2       = Color(0xFF243D65)
val Accent        = Color(0xFF7C6FFF)
val AccentLight   = Color(0xFF9D93FF)
val Cyan          = Color(0xFF00E5FF)
val Green         = Color(0xFF00E5A0)
val Amber         = Color(0xFFFFB830)
val Red           = Color(0xFFFF4D6D)
val White         = Color(0xFFF0F4FF)
val TextSecondary = Color(0xFFA8BFDD)
val Muted         = Color(0xFF4A6080)

private val DarkColorScheme = darkColorScheme(
    primary          = Accent,
    onPrimary        = White,
    secondary        = Cyan,
    onSecondary      = BgPrimary,
    tertiary         = Green,
    background       = BgPrimary,
    surface          = Surface1,
    onBackground     = White,
    onSurface        = White,
    outline          = Border1,
    primaryContainer = Surface2,
    onPrimaryContainer = TextSecondary,
)

@Composable
fun PresencePulseTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography  = PresencePulseTypography,
        content     = content
    )
}
