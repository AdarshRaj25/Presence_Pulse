package com.blackbox.presencepulse.service

import com.blackbox.presencepulse.data.db.PhubEventEntity

/**
 * Pure scoring engine.
 *
 * event_score = U_intensity × W_social × C_confirm × contextWeight  (0–100)
 * daily_score = 100 - (Σ scores / max_possible) × 100               (0–100)
 *
 * W_social:      known = 1.0, unknown = 0.6
 * C_confirm:     yes = 1.0, timeout = 0.7, no = 0.0
 * U_intensity:   screenOnMs / 300_000 capped at 1.0
 * contextWeight: from ContextSettingsManager (1.5 for dinner, 0.8 for class, etc.)
 *
 * ML confidence heuristic (shown on overlay, not used in scoring):
 *   Base = 0.5
 *   + 0.2 if known friend nearby
 *   + 0.1 for each 60s of screen-on (max +0.2)
 *   + 0.1 if social/entertainment app detected
 *   Capped at 0.95
 */
object PhubScorer {

    private const val WINDOW_CAP_MS = 300_000f

    // ── Event score ───────────────────────────────────────────────────────────

    fun computeEventScore(event: PhubEventEntity): Float {
        val wSocial = if (event.socialContext == "known") 1.0f else 0.6f

        val cConfirm = when (event.confirmation) {
            "yes"     -> 1.0f
            "timeout" -> 0.7f
            else      -> 0.0f
        }

        val uIntensity    = (event.screenOnMs / WINDOW_CAP_MS).coerceIn(0f, 1f)
        val contextWeight = event.contextWeight.coerceAtLeast(0.1f)

        return uIntensity * wSocial * cConfirm * contextWeight * 100f
    }

    // ── Daily score ───────────────────────────────────────────────────────────

    fun computeDailyScore(events: List<PhubEventEntity>): Pair<Int, Int> {
        if (events.isEmpty()) return Pair(100, 0)

        val active = events.filter { it.confirmation in listOf("yes", "timeout") }
        if (active.isEmpty()) return Pair(100, 0)

        val sumScores   = active.sumOf { computeEventScore(it).toDouble() }.toFloat()
        val maxPossible = active.size * 100f * 1.5f  // 1.5 is max context weight
        val phubRatio   = (sumScores / maxPossible).coerceIn(0f, 1f)
        val score       = ((1f - phubRatio) * 100f).toInt().coerceIn(0, 100)
        val phubCount   = events.count { it.confirmation == "yes" }

        return Pair(score, phubCount)
    }

    // ── ML confidence heuristic ───────────────────────────────────────────────
    // Shown on the overlay to help user decide. Not used in scoring.

    fun computeConfidence(
        screenOnMs    : Long,
        knownCount    : Int,
        unknownCount  : Int,
        topCategory   : String
    ): Float {
        var confidence = 0.5f

        // Known friends nearby = stronger signal
        if (knownCount > 0) confidence += 0.2f
        else if (unknownCount > 0) confidence += 0.05f

        // Longer screen-on = more likely phubbing
        val screenOnMins = screenOnMs / 60_000f
        confidence += (screenOnMins / 60f).coerceAtMost(0.2f)

        // Social/entertainment apps = higher signal
        if (topCategory in listOf("Social", "Video", "Game", "News")) {
            confidence += 0.1f
        }

        return confidence.coerceIn(0f, 0.95f)
    }

    // ── Format screen-on duration for display ─────────────────────────────────

    fun formatScreenOn(screenOnMs: Long): String {
        val totalSecs = screenOnMs / 1000
        val mins      = totalSecs / 60
        val secs      = totalSecs % 60
        return when {
            mins > 0 -> "${mins} min ${secs} sec screen-on"
            else     -> "${secs} sec screen-on"
        }
    }
}