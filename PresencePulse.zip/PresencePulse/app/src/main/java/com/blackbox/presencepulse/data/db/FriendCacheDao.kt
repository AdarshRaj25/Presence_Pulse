package com.blackbox.presencepulse.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface FriendCacheDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(friends: List<FriendCacheEntity>)

    @Query("SELECT * FROM friend_cache")
    suspend fun getAll(): List<FriendCacheEntity>

    @Query("DELETE FROM friend_cache")
    suspend fun clearAll()
}