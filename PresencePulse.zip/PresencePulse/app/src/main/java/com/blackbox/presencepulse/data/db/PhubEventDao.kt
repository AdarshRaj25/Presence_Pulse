package com.blackbox.presencepulse.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface PhubEventDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(event: PhubEventEntity): Long

    @Update
    suspend fun update(event: PhubEventEntity)

    @Query("SELECT * FROM phub_events WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): PhubEventEntity?

    // ── Scorer queries ────────────────────────────────────────────────────────

    // All confirmed events (yes + timeout) since a timestamp — for daily score
    @Query("""
        SELECT * FROM phub_events
        WHERE timestampMs >= :fromMs
        AND confirmation IN ('yes', 'timeout')
        ORDER BY timestampMs DESC
    """)
    suspend fun getConfirmedSince(fromMs: Long): List<PhubEventEntity>

    // Count of confirmed phub events today
    @Query("""
        SELECT COUNT(*) FROM phub_events
        WHERE timestampMs >= :fromMs
        AND confirmation = 'yes'
    """)
    suspend fun confirmedCountSince(fromMs: Long): Int

    // Pending events (nudge sent, no response yet)
    @Query("""
        SELECT * FROM phub_events
        WHERE confirmation = 'pending'
        ORDER BY timestampMs ASC
    """)
    suspend fun getPendingEvents(): List<PhubEventEntity>

    // ── Insights queries ──────────────────────────────────────────────────────

    // Daily phub count for last N days — for bar chart
    @Query("""
        SELECT (timestampMs / 86400000) * 86400000 AS dayBucket,
               COUNT(*) AS count
        FROM phub_events
        WHERE timestampMs >= :fromMs
        AND confirmation IN ('yes', 'timeout')
        GROUP BY dayBucket
        ORDER BY dayBucket ASC
    """)
    suspend fun dailyPhubCountSince(fromMs: Long): List<DailyPhubCount>

    // Top apps causing phubbing
    @Query("""
        SELECT topPackage, topCategory, COUNT(*) as count
        FROM phub_events
        WHERE timestampMs >= :fromMs
        AND confirmation = 'yes'
        AND topPackage != ''
        GROUP BY topPackage
        ORDER BY count DESC
        LIMIT 5
    """)
    suspend fun topPhubAppsSince(fromMs: Long): List<TopPhubApp>

    // Delete old events beyond 90 days
    @Query("DELETE FROM phub_events WHERE timestampMs < :cutoffMs")
    suspend fun deleteOlderThan(cutoffMs: Long)
}

data class DailyPhubCount(
    val dayBucket : Long,
    val count     : Int
)

data class TopPhubApp(
    val topPackage  : String,
    val topCategory : String,
    val count       : Int
)