package com.blackbox.presencepulse.ui.screens

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.blackbox.presencepulse.ui.components.*
import com.blackbox.presencepulse.ui.theme.*

private val ONBOARDING_TOP_PADDING = 42.dp

data class OnboardingStep(
    val icon      : String,
    val title     : String,
    val desc      : String,
    val permLabel : String,
    val chipStyle : ChipStyle
)

@Composable
fun OnboardingScreen(
    steps    : List<OnboardingStep>,
    onFinish : () -> Unit
) {
    val context = LocalContext.current
    var step    by remember { mutableIntStateOf(0) }

    if (steps.isEmpty()) {
        LaunchedEffect(Unit) { onFinish() }
        return
    }

    val current = steps[step]

    fun advance() {
        if (step < steps.lastIndex) step++ else onFinish()
    }

    // ── BLE permissions (SCAN + CONNECT + ADVERTISE) ──────────────────────────
    val blePermissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        arrayOf(
            android.Manifest.permission.BLUETOOTH_SCAN,
            android.Manifest.permission.BLUETOOTH_CONNECT,
            android.Manifest.permission.BLUETOOTH_ADVERTISE
        )
    } else {
        arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION)
    }
    val bleLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { advance() }

    // ── Notification permission ───────────────────────────────────────────────
    val notifLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { advance() }

    // ── Activity Recognition permission ───────────────────────────────────────
    val activityLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { advance() }

    // ── Settings-based permissions (Usage Stats + Overlay) ───────────────────
    // Both open a Settings screen — we advance when user returns via onResume.
    var awaitingSettingsReturn by remember { mutableStateOf(false) }

    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME && awaitingSettingsReturn) {
                awaitingSettingsReturn = false
                advance()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    fun onAllow() {
        when (current.title) {

            "Bluetooth Scanning" ->
                bleLauncher.launch(blePermissions)

            "App Usage Access" -> {
                awaitingSettingsReturn = true
                context.startActivity(
                    Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
                        try { data = Uri.parse("package:${context.packageName}") }
                        catch (_: Exception) {}
                    }
                )
            }

            "Notifications" -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    notifLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                } else {
                    advance()
                }
            }

            "Activity Recognition" -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    activityLauncher.launch(android.Manifest.permission.ACTIVITY_RECOGNITION)
                } else {
                    advance()
                }
            }

            "Display Over Apps" -> {
                awaitingSettingsReturn = true
                context.startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:${context.packageName}")
                    )
                )
            }

            else -> advance()
        }
    }

    // ── UI ────────────────────────────────────────────────────────────────────
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgPrimary)
            .verticalScroll(rememberScrollState())
    ) {
        // Progress dots
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(top = ONBOARDING_TOP_PADDING),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            steps.forEachIndexed { i, _ ->
                Box(
                    modifier = Modifier
                        .height(3.dp)
                        .weight(1f)
                        .clip(RoundedCornerShape(2.dp))
                        .background(if (i <= step) Accent else Border1)
                )
            }
        }

        Spacer(Modifier.height(32.dp))

        Column(
            modifier            = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .clip(RoundedCornerShape(30.dp))
                    .background(Brush.linearGradient(listOf(Surface2, Surface1)))
                    .border(1.dp, Border2, RoundedCornerShape(30.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(current.icon, fontSize = 44.sp)
            }

            Spacer(Modifier.height(28.dp))

            PPChip("Setup ${step + 1} of ${steps.size}", current.chipStyle)
            Spacer(Modifier.height(16.dp))

            Text(current.title, fontFamily = HeadingFamily, fontSize = 26.sp, color = White)
            Spacer(Modifier.height(12.dp))
            Text(current.desc, fontSize = 14.sp, color = TextSecondary, lineHeight = 22.sp)

            Spacer(Modifier.height(40.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Surface1)
                    .border(1.dp, Border1, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("🔒 Privacy First", fontSize = 12.sp, color = Accent)
                    Text(
                        "PresencePulse never shares your data. All detection happens on-device.",
                        fontSize = 12.sp, color = TextSecondary, lineHeight = 18.sp
                    )
                }
            }

            Spacer(Modifier.height(24.dp))

            PrimaryButton(label = current.permLabel, onClick = { onAllow() })

            Spacer(Modifier.height(12.dp))

            SecondaryButton(
                label   = if (step < steps.lastIndex) "Skip for now" else "Skip & Continue",
                onClick = { advance() }
            )

            Spacer(Modifier.height(24.dp))
        }
    }
}