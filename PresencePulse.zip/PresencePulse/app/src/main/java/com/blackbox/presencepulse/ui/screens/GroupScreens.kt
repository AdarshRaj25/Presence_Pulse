package com.blackbox.presencepulse.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.blackbox.presencepulse.firebase.Friend
import com.blackbox.presencepulse.firebase.FriendRequest
import com.blackbox.presencepulse.navigation.Routes
import com.blackbox.presencepulse.ui.components.*
import com.blackbox.presencepulse.ui.theme.*
import com.blackbox.presencepulse.viewmodel.FriendViewModel

// ═══════════════════════════════════════════════════════════════
// GROUP MANAGEMENT SCREEN  (Friends hub)
// ═══════════════════════════════════════════════════════════════

@Composable
fun GroupScreen(
    onBack        : () -> Unit,
    navController : NavController,
    friendViewModel: FriendViewModel = viewModel()
) {
    val uiState by friendViewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        containerColor = BgPrimary,
        bottomBar = {
            BottomTabBar(current = TabDestination.Group) { dest ->
                when (dest) {
                    TabDestination.Home     -> navController.navigate(Routes.HOME) { popUpTo(Routes.HOME) }
                    TabDestination.Live     -> navController.navigate(Routes.DETECTION)
                    TabDestination.Insights -> navController.navigate(Routes.INSIGHTS)
                    TabDestination.Settings -> navController.navigate(Routes.PERSONALIZATION)
                    else -> {}
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
        ) {
            TopNavBar(title = "Friends", onBack = onBack)

            // ── Add Friend by Email ───────────────────────────────────────
            SectionTitle("Add a Friend", modifier = Modifier.padding(horizontal = 20.dp))

            Column(
                modifier = Modifier
                    .padding(horizontal = 20.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Surface1)
                    .border(1.dp, Border1, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                PPTextField(
                    value         = uiState.searchEmail,
                    onValueChange = { friendViewModel.onSearchEmailChange(it) },
                    label         = "Search by email",
                    placeholder   = "friend@example.com"
                )

                Spacer(Modifier.height(12.dp))

                PrimaryButton(
                    label   = if (uiState.isSearching) "Searching…" else "Search",
                    onClick = { if (!uiState.isSearching) friendViewModel.searchUser() },
                    modifier = Modifier.fillMaxWidth()
                )

                // ── Search result ─────────────────────────────────────────
                uiState.searchError?.let { error ->
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "⚠ $error",
                        fontSize = 12.sp,
                        color    = Red,
                        modifier = Modifier.padding(horizontal = 2.dp)
                    )
                }

                uiState.searchResult?.let { result ->
                    Spacer(Modifier.height(12.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Surface2)
                            .border(1.dp, Border1, RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        verticalAlignment     = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Avatar
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(listOf(Accent, Color(0xFF5046E5)))),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                result.name.take(1).uppercase(),
                                fontSize   = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color      = White
                            )
                        }
                        Column(Modifier.weight(1f)) {
                            Text(result.name, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = White)
                            Text(result.email, fontSize = 11.sp, color = Muted)
                        }

                        when {
                            uiState.requestSent -> PPChip("SENT ✓", ChipStyle.GREEN)

                            uiState.isSendingReq -> CircularProgressIndicator(
                                modifier    = Modifier.size(20.dp),
                                color       = Accent,
                                strokeWidth = 2.dp
                            )

                            else -> Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(Accent)
                                    .clickable { friendViewModel.sendRequest(result.uid, result.name) }
                                    .padding(horizontal = 14.dp, vertical = 7.dp)
                            ) {
                                Text(
                                    "Add Friend",
                                    fontSize   = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color      = White
                                )
                            }
                        }
                    }

                    uiState.requestError?.let { err ->
                        Spacer(Modifier.height(8.dp))
                        Text("⚠ $err", fontSize = 12.sp, color = Red)
                    }
                }
            }

            // ── Incoming Friend Requests ──────────────────────────────────
            if (uiState.incomingRequests.isNotEmpty()) {
                SectionTitle(
                    "Friend Requests  •  ${uiState.incomingRequests.size}",
                    modifier = Modifier.padding(horizontal = 20.dp)
                )
                uiState.incomingRequests.forEach { request ->
                    IncomingRequestRow(
                        request  = request,
                        onAccept = { friendViewModel.acceptRequest(request) },
                        onReject = { friendViewModel.rejectRequest(request.requestId) }
                    )
                }
            }

            // ── Friends List ──────────────────────────────────────────────
            SectionTitle(
                "My Friends  •  ${uiState.friends.size}",
                modifier = Modifier.padding(horizontal = 20.dp)
            )

            if (uiState.friends.isEmpty()) {
                Box(
                    modifier = Modifier
                        .padding(horizontal = 20.dp, vertical = 4.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Surface1)
                        .border(1.dp, Border1, RoundedCornerShape(12.dp))
                        .padding(16.dp)
                ) {
                    Text(
                        "No friends yet. Search by email above to add people.",
                        fontSize   = 12.sp,
                        color      = TextSecondary,
                        lineHeight = 18.sp
                    )
                }
            } else {
                uiState.friends.forEach { friend ->
                    FriendRow(friend = friend)
                }
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

// ── Incoming Request Row ──────────────────────────────────────────────────────

@Composable
private fun IncomingRequestRow(
    request  : FriendRequest,
    onAccept : () -> Unit,
    onReject : () -> Unit
) {
    Row(
        modifier = Modifier
            .padding(horizontal = 20.dp, vertical = 4.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Surface1)
            .border(1.dp, Accent.copy(alpha = 0.3f), RoundedCornerShape(14.dp))
            .padding(12.dp),
        verticalAlignment     = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Cyan, Color(0xFF0099BB)))),
            contentAlignment = Alignment.Center
        ) {
            Text(
                request.fromName.take(1).uppercase(),
                fontSize   = 15.sp,
                fontWeight = FontWeight.Bold,
                color      = White
            )
        }

        Column(Modifier.weight(1f)) {
            Text(request.fromName, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = White)
            Text("wants to be friends", fontSize = 11.sp, color = Muted)
        }

        // Accept
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(Green.copy(alpha = 0.15f))
                .border(1.dp, Green.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                .clickable { onAccept() }
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Text("✓", fontSize = 13.sp, color = Green, fontWeight = FontWeight.Bold)
        }

        // Reject
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(Red.copy(alpha = 0.10f))
                .border(1.dp, Red.copy(alpha = 0.3f), RoundedCornerShape(20.dp))
                .clickable { onReject() }
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Text("✕", fontSize = 13.sp, color = Red, fontWeight = FontWeight.Bold)
        }
    }
}

// ── Friend Row ────────────────────────────────────────────────────────────────

@Composable
private fun FriendRow(friend: Friend) {
    Row(
        modifier = Modifier
            .padding(horizontal = 20.dp, vertical = 4.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Surface1)
            .border(1.dp, Border1, RoundedCornerShape(12.dp))
            .padding(12.dp),
        verticalAlignment     = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Accent, Color(0xFF5046E5)))),
            contentAlignment = Alignment.Center
        ) {
            Text(
                friend.name.take(1).uppercase(),
                fontSize   = 15.sp,
                fontWeight = FontWeight.Bold,
                color      = White
            )
        }
        Text(
            friend.name,
            fontSize   = 13.sp,
            fontWeight = FontWeight.Medium,
            color      = White,
            modifier   = Modifier.weight(1f)
        )
        PPChip("FRIEND", ChipStyle.ACCENT)
    }
}

// ═══════════════════════════════════════════════════════════════
// GROUP DASHBOARD SCREEN  (unchanged structure, kept intact)
// ═══════════════════════════════════════════════════════════════

private data class LeaderboardEntry(
    val rank       : String,
    val emoji      : String,
    val name       : String,
    val sub        : String,
    val score      : Int,
    val scoreColor : Color,
    val rowBg      : Color,
    val rowBorder  : Color,
    val barBrush   : Brush
)

@Composable
fun GroupDashScreen(onBack: () -> Unit, navController: NavController) {
    val leaderboard = listOf(
        LeaderboardEntry("🥇", "👦", "Rohan",      "0 nudges · 6h phone-free", 97, Green,
            Color(0x10FFB830), Color(0x66FFB830),
            Brush.horizontalGradient(listOf(Green,  Green.copy(alpha = 0f)))),
        LeaderboardEntry("🥈", "😊", "Alex (You)", "2 nudges · 4h phone-free", 92, Accent,
            Color(0x107C6FFF), Color(0x667C6FFF),
            Brush.horizontalGradient(listOf(Accent, Accent.copy(alpha = 0f)))),
        LeaderboardEntry("🥉", "👩", "Priya",      "5 nudges · 2h phone-free", 68, Amber,
            Surface1, Border1,
            Brush.horizontalGradient(listOf(Amber,  Amber.copy(alpha = 0f)))),
    )

    Scaffold(
        containerColor = BgPrimary,
        bottomBar = {
            BottomTabBar(current = TabDestination.Group) { dest ->
                when (dest) {
                    TabDestination.Home     -> navController.navigate(Routes.HOME) { popUpTo(Routes.HOME) }
                    TabDestination.Live     -> navController.navigate(Routes.DETECTION)
                    TabDestination.Insights -> navController.navigate(Routes.INSIGHTS)
                    TabDestination.Settings -> navController.navigate(Routes.PERSONALIZATION)
                    else -> {}
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
        ) {
            TopNavBar(title = "Group", onBack = onBack, actionLabel = "Friends") {
                navController.navigate(Routes.GROUP)
            }

            // Group Header
            Row(
                modifier = Modifier
                    .padding(horizontal = 20.dp, vertical = 8.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(Surface1)
                    .border(1.dp, Border1, RoundedCornerShape(18.dp))
                    .padding(16.dp),
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Brush.linearGradient(listOf(Cyan.copy(alpha = 0.2f), Accent.copy(alpha = 0.2f))))
                        .border(1.dp, Border2, RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) { Text("👨‍👩‍👧‍👦", fontSize = 22.sp) }
                Column(Modifier.weight(1f)) {
                    Text("Friends Group", fontFamily = HeadingFamily, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = White)
                    Text("Goal active", fontSize = 11.sp, color = Muted)
                }
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Green.copy(alpha = 0.12f))
                        .border(1.dp, Green.copy(alpha = 0.3f), RoundedCornerShape(20.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment     = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    PulsingDot(Green)
                    Text("LIVE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Green, letterSpacing = 1.sp)
                }
            }

            // Goal Card
            Column(
                modifier = Modifier
                    .padding(horizontal = 20.dp, vertical = 4.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Surface1)
                    .border(1.dp, Border1, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Row(
                    modifier              = Modifier.fillMaxWidth().padding(bottom = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment     = Alignment.CenterVertically
                ) {
                    Text("🎯 Dinner Goal", fontFamily = HeadingFamily, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = White)
                    PPChip("Active", ChipStyle.GREEN)
                }
                Text("Phone-free during dinner · 7–8 PM daily", fontSize = 11.sp, color = Muted, modifier = Modifier.padding(bottom = 10.dp))
                Box(
                    modifier = Modifier.fillMaxWidth().height(8.dp)
                        .clip(RoundedCornerShape(4.dp)).background(Surface2)
                ) {
                    Box(
                        modifier = Modifier.fillMaxWidth(0.67f).fillMaxHeight()
                            .clip(RoundedCornerShape(4.dp))
                            .background(Brush.horizontalGradient(listOf(Accent, Cyan)))
                    )
                }
                Row(
                    modifier              = Modifier.fillMaxWidth().padding(top = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("2 of 3 members achieved today", fontSize = 10.sp, color = Muted)
                    Text("67%", fontSize = 10.sp, color = Accent)
                }
            }

            // Leaderboard
            SectionTitle("Today's Leaderboard", modifier = Modifier.padding(horizontal = 20.dp))
            Column(modifier = Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                leaderboard.forEach { entry ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(entry.rowBg)
                            .border(1.dp, entry.rowBorder, RoundedCornerShape(14.dp))
                    ) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .fillMaxWidth(entry.score / 100f)
                                .height(2.dp)
                                .background(entry.barBrush)
                        )
                        Row(
                            modifier              = Modifier.padding(12.dp),
                            verticalAlignment     = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(entry.rank, fontSize = 18.sp, modifier = Modifier.width(28.dp))
                            Box(
                                modifier = Modifier.size(38.dp).clip(RoundedCornerShape(11.dp)).background(Surface2),
                                contentAlignment = Alignment.Center
                            ) { Text(entry.emoji, fontSize = 18.sp) }
                            Column(Modifier.weight(1f)) {
                                Text(entry.name, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = White)
                                Text(entry.sub, fontSize = 10.sp, color = Muted, modifier = Modifier.padding(top = 2.dp))
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(entry.score.toString(), fontFamily = HeadingFamily, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = entry.scoreColor)
                                Text("SCORE", fontSize = 9.sp, color = Muted, letterSpacing = 0.5.sp)
                            }
                        }
                    }
                }
            }

            // Nudge Actions
            SectionTitle("Nudge a Friend", modifier = Modifier.padding(horizontal = 20.dp))
            Row(
                modifier              = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                NudgeActionCard("👩", "Nudge Priya", "Hey, put it down 👀", Modifier.weight(1f))
                NudgeActionCard("🎯", "Set Goal",    "New shared goal",     Modifier.weight(1f))
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun NudgeActionCard(icon: String, title: String, sub: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Surface1)
            .border(1.dp, Border1, RoundedCornerShape(12.dp))
            .clickable {}
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(icon, fontSize = 20.sp)
        Text(title, fontSize = 11.sp, color = TextSecondary, fontWeight = FontWeight.SemiBold)
        Text(sub,   fontSize = 10.sp, color = Muted)
    }
}