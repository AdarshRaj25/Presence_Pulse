package com.blackbox.presencepulse.ble

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.blackbox.presencepulse.permissions.PermissionUtils
import com.google.firebase.auth.FirebaseAuth

/**
 * Receives BOOT_COMPLETED and restarts BleBackgroundService.
 * Only starts if the user is logged in AND all BLE permissions are granted —
 * no point starting the service if the user hasn't set up the app yet.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        val isLoggedIn     = FirebaseAuth.getInstance().currentUser != null
        val hasPermissions = PermissionUtils.isBleGranted(context)

        if (isLoggedIn && hasPermissions) {
            BleBackgroundService.start(context)
        }
    }
}