package com.blackbox.presencepulse.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.blackbox.presencepulse.ble.BleBackgroundService
import com.blackbox.presencepulse.data.repository.UsageRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class InsightsUiState(
    val isLoading      : Boolean                              = true,
    val todayScore     : Int                                  = 0,
    val phubCount      : Int                                  = 0,
    val scoreLabel     : String                               = "",
    val scoreColor     : ScoreColor                           = ScoreColor.NEUTRAL,
    val socialMins     : Int                                  = 0,
    val pickupCount    : Int                                  = 0,
    val streakDays     : Int                                  = 0,
    val bleDeviceCount : Int                                  = 0,
    val weeklyScores   : List<Pair<String, Float>>            = emptyList(),
    val heatmapData    : List<Float>                          = emptyList(),
    val keyInsights    : List<Triple<String, String, String>> = emptyList()
)

enum class ScoreColor { GREAT, GOOD, NEUTRAL, POOR }

class InsightsViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = UsageRepository(app.applicationContext)

    private val _uiState = MutableStateFlow(InsightsUiState())
    val uiState: StateFlow<InsightsUiState> = _uiState.asStateFlow()

    init {
        loadAll()
        viewModelScope.launch {
            BleBackgroundService.deviceCount.collect { count ->
                _uiState.value = _uiState.value.copy(bleDeviceCount = count)
            }
        }
    }

    fun loadAll() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)

            val (score, phubCount) = repo.getTodayScoreAndCount()
            val pickups            = repo.getTodayPickupCount()
            val streak             = repo.getCurrentStreak()
            val weeklyScores       = repo.getWeeklyScores()
            val heatmap            = repo.getHeatmapData()
            val insights           = repo.getKeyInsights()
            val bleCount           = BleBackgroundService.deviceCount.value

            val scoreColor = when {
                score >= 85 -> ScoreColor.GREAT
                score >= 70 -> ScoreColor.GOOD
                score >= 50 -> ScoreColor.NEUTRAL
                else        -> ScoreColor.POOR
            }
            val scoreLabel = when {
                score >= 85 -> "Excellent presence!"
                score >= 70 -> "Good presence today"
                score >= 50 -> "Room to improve"
                else        -> "$phubCount phub${if (phubCount == 1) "" else "s"} today"
            }

            val socialMins  = BleBackgroundService.socialMinutesToday.value

            _uiState.value = InsightsUiState(
                isLoading      = false,
                todayScore     = score,
                phubCount      = phubCount,
                scoreLabel     = scoreLabel,
                scoreColor     = scoreColor,
                socialMins     = socialMins,
                pickupCount    = pickups,
                streakDays     = streak,
                bleDeviceCount = bleCount,
                weeklyScores   = weeklyScores,
                heatmapData    = heatmap,
                keyInsights    = insights
            )
        }
    }
}